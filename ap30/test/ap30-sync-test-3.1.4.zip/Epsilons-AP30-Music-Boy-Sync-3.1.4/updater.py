"""
Update check and self-update for Epsilon's AP30 Music Boy Sync.

The newest version is described by a small file on the download site:
    https://downloads.epsilonsworld.com/ap30/latest.json
    {"version": "3.1", "url": "https://github.com/epsilonsworld/downloads/releases/download/v3.1/...zip",
     "sha256": "...", "size": 12345678, "notes": "...", "page": "https://github.com/.../releases/tag/v3.1"}
It is updated automatically by a GitHub Action whenever a new release is published.

Updating downloads the zip from GitHub, checks it against the SHA-256 in latest.json,
unpacks it into a temporary folder and runs its install.sh - exactly what a person does by
hand. Settings, playlists and caches live in a separate folder and are kept.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import threading
import time
import zipfile

LATEST_URL = "https://downloads.epsilonsworld.com/ap30/latest.json"
# Test channel: a Mac with the word "test" in <settings folder>/update-channel reads this file instead,
# so updating can be tried out with a test build without offering anything to anyone else.
TEST_URL = "https://downloads.epsilonsworld.com/ap30/latest-test.json"
ALLOWED_PREFIXES = ("https://github.com/epsilonsworld/downloads/releases/download/",
                    "https://downloads.epsilonsworld.com/")
CHECK_EVERY = 24 * 3600
MAX_ZIP = 200 * 1024 * 1024


def vtuple(v):
    """'3.0.2' -> (3, 0, 2). Anything that isn't a version number sorts lowest."""
    nums = re.findall(r"\d+", str(v or ""))
    return tuple(int(n) for n in nums[:4]) or (0,)


def newer(a, b):
    """Is version a newer than version b?"""
    ta, tb = vtuple(a), vtuple(b)
    n = max(len(ta), len(tb))
    return ta + (0,) * (n - len(ta)) > tb + (0,) * (n - len(tb))


class Updater:
    def __init__(self, app_dir, current, which, log=lambda m: None):
        self.app_dir = app_dir
        self.current = current
        self.which = which
        self.log = log
        self.channel = "release"
        try:
            with open(os.path.join(app_dir, "update-channel")) as fh:
                if fh.read().strip().lower() == "test":
                    self.channel = "test"
        except OSError:
            pass
        self.url = TEST_URL if self.channel == "test" else LATEST_URL
        self.cache = os.path.join(app_dir, "update-test.json" if self.channel == "test" else "update.json")
        self.lock = threading.Lock()
        self.status = {"state": "idle", "message": "", "latest": None, "checked": 0}
        self.opener = lambda path: subprocess.run(["/usr/bin/open", "-a", "Terminal", path],
                                                  capture_output=True, timeout=30).returncode
        try:
            with open(self.cache) as fh:
                c = json.load(fh)
            self.status.update(latest=c.get("latest"), checked=c.get("checked", 0))
        except (OSError, ValueError):
            pass

    # ------------------------------------------------------------ check
    def _curl(self, args, timeout):
        curl = self.which("curl")
        if not curl:
            raise OSError("curl not found")
        r = subprocess.run([curl, "-sfL", "--proto", "=https", "--max-filesize", str(MAX_ZIP),
                            "-m", str(timeout), "-A", f"AP30MusicBoySync/{self.current}"] + args,
                           capture_output=True)
        if r.returncode != 0:
            raise OSError(f"download failed (curl {r.returncode})")
        return r.stdout

    def check(self, force=False):
        """Returns {"available": bool, "latest": {...} or None, "error": str}. Asks the site at most
        once a day unless forced; failures (offline) are quiet."""
        now = time.time()
        latest, err = self.status.get("latest"), ""
        if force or now - self.status.get("checked", 0) > CHECK_EVERY or not latest:
            try:
                raw = self._curl([self.url + f"?t={int(now)}"], 15)
                info = json.loads(raw.decode("utf-8"))
                if not isinstance(info, dict) or not info.get("version"):
                    raise ValueError("no version in latest.json")
                latest = {k: info.get(k) for k in ("version", "url", "sha256", "size", "notes", "page", "date")}
                self.status.update(latest=latest, checked=now)
                try:
                    with open(self.cache, "w") as fh:
                        json.dump({"latest": latest, "checked": now}, fh)
                except OSError:
                    pass
            except (OSError, ValueError) as e:
                err = "Couldn't check for updates (offline?)" if isinstance(e, OSError) else f"Bad update information: {e}"
                self.log(f"update check: {e}")
        avail = bool(latest and newer(latest.get("version"), self.current))
        return {"available": avail, "current": self.current, "latest": latest, "error": err, "channel": self.channel,
                "checked": self.status.get("checked", 0), "state": self.status["state"],
                "message": self.status["message"]}

    # ------------------------------------------------------------ install
    def start_install(self, on_installed):
        with self.lock:
            if self.status["state"] in ("downloading", "installing", "restarting"):
                return False, "An update is already running."
            latest = self.status.get("latest")
            if not latest or not newer(latest.get("version"), self.current):
                return False, "There is no newer version to install."
            self.status.update(state="downloading", message=f"Downloading version {latest['version']}…")
        threading.Thread(target=self._install, args=(latest, on_installed), daemon=True).start()
        return True, ""

    def _fail(self, msg):
        self.log("update failed: " + msg)
        self.status.update(state="failed", message=msg)

    def _install(self, latest, on_installed):
        # Work in the program's own data folder (not the system's temporary folder), so the
        # unpacked update is still there when the installer runs in its Terminal window.
        work = os.path.join(self.app_dir, "update")
        shutil.rmtree(work, ignore_errors=True)
        os.makedirs(work, exist_ok=True)
        try:
            url, want = str(latest.get("url") or ""), str(latest.get("sha256") or "").lower()
            if not url.startswith(ALLOWED_PREFIXES):
                return self._fail("The update's download address isn't on EpsilonsWorld's GitHub - not installed.")
            if not re.fullmatch(r"[0-9a-f]{64}", want):
                return self._fail("The update information has no valid checksum - not installed.")
            zpath = os.path.join(work, "update.zip")
            try:
                data = self._curl([url], 600)
            except OSError as e:
                return self._fail(f"Couldn't download the update ({e}). Try again later.")
            if hashlib.sha256(data).hexdigest() != want:
                return self._fail("The downloaded file didn't match its checksum (damaged or changed) - not installed.")
            with open(zpath, "wb") as fh:
                fh.write(data)
            self.status.update(state="installing", message=f"Unpacking version {latest['version']}…")
            dest = os.path.join(work, "unzipped")
            os.makedirs(dest)
            with zipfile.ZipFile(zpath) as z:
                for m in z.infolist():
                    target = os.path.realpath(os.path.join(dest, m.filename))
                    if not target.startswith(os.path.realpath(dest) + os.sep) or m.filename.startswith("__MACOSX"):
                        continue                              # skip unsafe paths and macOS junk
                    z.extract(m, dest)
            folder = None
            for root, dirs, files in os.walk(dest):
                if "install.sh" in files and "server.py" in files:
                    folder = root
                    break
            if not folder:
                return self._fail("The update doesn't contain the program - not installed.")
            try:
                with open(os.path.join(folder, "server.py"), encoding="utf-8") as fh:
                    m = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', fh.read())
                if not m or vtuple(m.group(1)) != vtuple(latest["version"]):
                    return self._fail("The update's version doesn't match - not installed.")
            except OSError:
                return self._fail("The update couldn't be read - not installed.")
            # The installer runs in its own Terminal window - exactly like installing by hand - so it
            # has the same permissions as a manual install and any macOS question can be seen.
            # (Run in the background, macOS can hold the installer up indefinitely while it replaces
            # the app, leaving it half installed.)
            log_path = os.path.join(self.app_dir, "update.log")
            cmd = os.path.join(work, "Install update.command")
            q = lambda x: "'" + x.replace("'", "'\\''") + "'"
            with open(cmd, "w") as fh:
                fh.write("#!/bin/bash\n"
                         f"# Installs Epsilon's AP30 Music Boy Sync {latest['version']} (started by the program's update)\n"
                         "export AP30SYNC_UPDATE=1\n"
                         f"cd {q(folder)} || exit 1\n"
                         f"echo \"--- $(date) updating {self.current} -> {latest['version']}\" >> {q(log_path)}\n"
                         f"bash install.sh 2>&1 | tee -a {q(log_path)}\n"
                         "rc=${PIPESTATUS[0]}\n"
                         "echo\n"
                         "if [ \"$rc\" = 0 ]; then\n"
                         "  echo \"The update has finished. This window closes by itself.\"\n"
                         "  T=\"$(tty)\"\n"
                         "  CLOSE=\"sleep 4; osascript -e 'tell application \\\"Terminal\\\" to close (every window whose tty of selected tab is \\\"$T\\\")'\"\n"
                         "  perl -MPOSIX -e 'POSIX::setsid(); exec @ARGV' /bin/sh -c \"$CLOSE\" </dev/null >/dev/null 2>&1 &\n"
                         "else\n"
                         "  echo \"The update did not finish (see above). Your previous version is still installed.\"\n"
                         "fi\n")
            os.chmod(cmd, 0o755)
            with open(os.path.join(self.app_dir, ".updating"), "w") as fh:
                fh.write(latest["version"])
            on_installed()
            r = self.opener(cmd)
            if r != 0:
                try:
                    os.remove(os.path.join(self.app_dir, ".updating"))
                except OSError:
                    pass
                return self._fail("Couldn't open Terminal to install the update. Install it by hand: unzip it and run "
                                  "bash install.sh - see the manual.")
            self.status.update(state="restarting",
                               message=f"A Terminal window is installing version {latest['version']} - "
                                       "the program restarts by itself in a moment…")
            self.log(f"Updating to {latest['version']}: installer opened in Terminal")
        except Exception as e:                                # never take the program down
            self._fail(f"Update failed: {e}")
