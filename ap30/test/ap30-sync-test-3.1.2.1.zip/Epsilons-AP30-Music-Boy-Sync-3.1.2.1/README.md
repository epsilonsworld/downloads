# Epsilon's AP30 Music Boy Sync — version 3.1.2

EpsilonsWorld.com presents **Epsilon's AP30 Music Boy Sync**,
by Epsilon / EpsilonsWorld.com, with the assistance of Claude AI.
https://www.epsilonsworld.com

The full illustrated manual is **Epsilon's AP30 Music Boy Sync - User Manual.pdf**
in this folder (also under Settings › User manual and About › Open the manual in
the program).

## Licence

Freeware. Copyright (c) 2026 Steven Jeffery (AKA Epsilon) / EpsilonsWorld.com.
Free to download and use for personal use; not to be redistributed, sold or
modified without written permission. **No warranty of any kind - use at your
own risk.** Full terms: LICENSE.txt.

## What's new in 3.1.2

- Fixed: "Update now" could leave the app half installed, so it wouldn't open.
  Updates now install in their own Terminal window, exactly like installing
  by hand, and the installer builds the new app beside the old one and only
  swaps it in once it's complete.
- The download unpacks into a folder named after the version (for example
  Epsilons-AP30-Music-Boy-Sync-3.1.2), so new downloads don't pile up as
  "...Sync 2", "...Sync 3".

## What's new in 3.1.1

- Two playlists can no longer be given the same name. Before, the second one
  was synced into its own folder (e.g. "Bonobo (2)"), duplicating every song.
  The card check now warns about any playlists that already share a name.

## What's new in 3.1

- Automatic updates: when the program opens it checks (at most once a day)
  for a newer version on downloads.epsilonsworld.com. A bar at the top offers
  "Update now", which downloads the new version from GitHub, checks it against
  its published checksum, installs it and restarts the program. Settings,
  playlists and port are kept. Turn the check off in Settings, or check any
  time with "Check for updates" in the About window.
- Online cover art now works for compilations and DJ mixes tagged with the
  album artist "Various Artists": they are looked up by album name, because
  Apple lists them under the DJ or label, not each track's artist. Album names
  with extras such as "NORTH" or "(Disc 1)" are retried without them.
- A cover.jpg in the folder above disc folders (Album/CD1, Album/CD2) is used.
- Songs left without a cover are tried again on the next sync.

## What's new in 3.0.1

- The program and installer now only use helper programs that actually run.
  Old PowerPC / 32-bit Intel copies left behind by earlier Macs or macOS
  upgrades ("bad CPU type in executable") are skipped and listed, in the
  installer's output and under "Won't run" in the About window.
- The manual has full instructions for installing the tools and for tidying
  up old programs (chapter 3, "Old programs left on your Mac").

## What's new in 3.0

- New name, Epsilon logo, an About window and links to EpsilonsWorld.com.
- The installer checks the program's web-server port (8730). If another
  program is using it, it offers a free port (or use `bash install.sh --port N`).
  The app and future installs remember the port. Older copies of the program,
  including "AP30 Sync", are recognised and replaced; your settings and
  playlists are kept.
- The sync log names every song left without a cover, so you can fix them.
- The "written" figure now includes files updated in place on the card.

## About

Make playlists from your FLAC library, and keep them and your Music app (iTunes)
playlists synced to the Hidizs AP30's microSD card, with a check that
everything fits under the AP30's 256 GB library limit.

## Install

1. Unzip, open Terminal in the unzipped folder, and run:

       bash install.sh

   It creates **Epsilon's AP30 Music Boy Sync** in your Applications folder and opens it. A
   Terminal window titled "Epsilon's AP30 Music Boy Sync" opens and runs the engine, and the app
   opens in your browser. Keep the Terminal window open (you can minimise it)
   while you use the app. Closing it stops the program. It runs in Terminal
   because Terminal already has macOS permission to read your music,
   Downloads folder and the card.

2. The installer checks that each tool it needs really runs and shows where it
   found it. A ✗ means install it; a "won't run" warning means an old copy is
   in the way (see below).

## Requirements and tools (install these first)

- A Mac with Apple Silicon or Intel, macOS 11 Big Sur or later.
- **Homebrew** (https://brew.sh). In Terminal:

      /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
      echo >> ~/.zprofile
      echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
      eval "$(/opt/homebrew/bin/brew shellenv)"

  (On an Intel Mac use `/usr/local/bin/brew` in the last two lines.)
- **Python 3, ImageMagick and ffmpeg** (ffmpeg only for Compact MP3 playlists),
  then **mutagen**:

      brew install python imagemagick ffmpeg
      python3 -m pip install --user --break-system-packages mutagen

  (If pip doesn't know `--break-system-packages`, leave it out.)
- Check each one runs:

      magick -version | head -1
      ffmpeg -version | head -1
      python3 -c "import mutagen; print('mutagen', mutagen.version_string)"

### "bad CPU type in executable" - old programs left on your Mac

Macs upgraded over many years, or moved from an older Mac, can still have old
PowerPC or 32-bit Intel programs in /usr/local/bin that current macOS can't run.

- Find every copy and what it's built for:

      which -a magick convert ffmpeg python3 flac metaflac
      file /usr/local/bin/convert        # "ppc" or "i386" = can't run

- Put Homebrew first: make sure the `brew shellenv` line above is in
  ~/.zprofile, then open a new Terminal window.
- Move (don't delete) the old copies out of the way, then reinstall with
  Homebrew. Never touch /usr/bin, /bin or /System:

      sudo mkdir -p /usr/local/old-programs
      sudo mv /usr/local/bin/convert /usr/local/old-programs/

- Apple Silicon Mac moved over from an Intel Mac: if `file /usr/local/bin/brew`
  says x86_64, install the Apple Silicon Homebrew as above (it goes into
  /opt/homebrew) and reinstall the tools with it.
- mutagen "missing": install it into Homebrew's Python directly:

      /opt/homebrew/bin/python3 -m pip install --break-system-packages mutagen

The manual's chapter 3 explains each step in more detail.

## First run (Settings tab)

- **FLAC library folders**: add the folder that holds your FLAC albums. The
  first scan reads every file's tags, so it can take a few minutes. Later
  scans only read new or changed files.
- **Library.xml**: your Music app export (File › Library › Export Library…).
  Export it again after you change playlists, then press Reload.
- **Card location**: `/Volumes/MUSICBOY`.
- If you've already copied your iTunes playlist folders to the card, rename
  that folder on the card to **iTunes Playlists**, or type its current name
  into "iTunes playlists folder". The app then recognises the files instead of
  copying them again.

## Making playlists (Playlists tab)

- Drag the dividers between the three panels to resize them; double-click a
  divider to reset it. The widths are remembered.

- Press **+** for a new playlist and type its name.
- Filter the library by title, artist, album or year. **Select all** selects
  everything the filter shows (or press ⌘A). ⇧-click or ⌘-click to select
  several tracks. Esc clears the selection.
- **▶** plays a track and ■ Stop (or Space) stops it. Playing from inside a
  playlist carries on through the playlist in order, so you can hear the
  running order.
- Add tracks by dragging them onto the playlist, double-clicking, or pressing
  **Add**. Drag ⋮⋮ to reorder. Select tracks and press Delete to remove them.
- **Lossless / Compact**: Compact turns that playlist's copies into MP3 320,
  about a third of the size. Your FLAC files are never changed.
- iTunes playlists: tick or untick which ones to sync. **Match card** ticks
  exactly the playlists that already have a folder on the card.

## The AP30's track limit

The AP30's library can only hold a limited number of tracks: about 7,055 music
files is known to work and about 7,400 is known to fail. Files past the limit are silently left out
(and the library scan may crash). The scan goes in the order folders were
created on the card, not alphabetically. Every copy counts: a song in five
playlists uses five slots.

- The meter at the top of the Playlists tab shows how many tracks the card
  will hold after syncing.
- Check card shows the same figure and warns when you're over. It also lists
  the playlists that are mostly duplicates of other playlists.
- The limit is a setting (Settings › AP30 track limit), starting at 7,000.
  To test a higher limit, set it, sync (confirm when asked), then rebuild the
  AP30's library: power off, card out, power on, card in.

## Syncing (Sync tab)

- **Check card & preview** shows what's on the card, a bar of how full it will
  be against the 256 GB limit, and what will be copied, renamed or removed.
  Nothing changes until you press **Sync now**.
- Cover art: every song gets a 300×300 front-cover JPEG embedded. Art that
  the AP30 can't show (big images, PNGs, progressive JPEGs, or images not
  marked "front cover", which iTunes often saves when you add art in Get
  Info) is converted on the copies. The art is taken from
  the song itself, then the Music app (iTunes Store purchases often have
  their artwork only in the Music app, not in the file; the first time,
  macOS asks whether Terminal may control Music - click OK), then its album
  folder (a cover image or another track on the album), then Apple's online
  iTunes artwork search (Settings can turn
  this off; lookups are cached, and about 20 a minute are allowed). MP3 tags
  are saved as ID3v2.3, which small players read reliably.
- Songs already on the card (including ones you copied yourself) are fixed in
  place: tags and cover art are updated without copying them again.
- Hidden macOS "._" junk files are removed from the whole card. The AP30
  tries to play them.
- Like iTunes sync, it only copies what changed. Reordering a playlist
  renames and re-tags the files already on the card instead of copying them
  again.

## On the card

    /FLAC/                your albums (never touched by the app)
    /FLAC Playlists/      one folder per FLAC playlist
    /iTunes Playlists/    one folder per Music app playlist
    /.ap30sync/           the app's record of what it copied

Each track is named `001 - Artist - Title`. FLAC playlist albums get
" [FLAC]" added to their album name (you can turn this off in Settings). The copies are tagged with album =
playlist name, track number = position, and album artist = "FLAC Playlists" or
"iTunes Playlists". In the AP30's library each playlist then shows as an album,
grouped away from your real albums. Covers are shrunk to 300×300 so the AP30
can show them.

**Your originals are never changed.** Your iTunes and FLAC folders are only
ever read; tag and cover-art changes are made to the copies. A safety lock
checks every write and delete. The app refuses to sync unless the card
location is a removable disk under /Volumes, outside your home folder and
music folders. It only writes inside the card's two playlist folders, and
anything else is refused. Junk-file cleanup also skips your music folders. Your music library is
only ever read.

Data: `~/Library/Application Support/AP30 Sync/`
Log: `~/Library/Logs/Epsilon's AP30 Music Boy Sync.log`
To quit: Settings › Quit the program, or close its Terminal window.
