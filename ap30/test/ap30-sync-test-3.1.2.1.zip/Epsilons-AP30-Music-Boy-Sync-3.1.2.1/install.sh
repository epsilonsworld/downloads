#!/bin/bash
# Installs "Epsilon's AP30 Music Boy Sync" into your Applications folder (~/Applications).
# By Epsilon / EpsilonsWorld.com, with the assistance of Claude AI - https://www.epsilonsworld.com
#
# Run from Terminal, in the unzipped folder:   bash install.sh
# Optional: bash install.sh --port 8740   (use a specific port for the program's local web server)
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
NAME="Epsilon's AP30 Music Boy Sync"
APP="$HOME/Applications/$NAME.app"
OLD_APP="$HOME/Applications/AP30 Sync.app"
DATA="$HOME/Library/Application Support/AP30 Sync"        # settings, playlists, caches (kept from earlier versions)
PORT_FILE="$DATA/port"
DEFAULT_PORT=8730
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

echo "================================================================"
echo " EpsilonsWorld.com presents $NAME"
echo " by Epsilon / EpsilonsWorld.com, with the assistance of Claude AI"
echo "================================================================"
echo

mkdir -p "$DATA"

# ---------------------------------------------------------------- port
WANT=""
if [ "$1" = "--port" ] && [ -n "$2" ]; then WANT="$2"; fi
PORT="$(cat "$PORT_FILE" 2>/dev/null | tr -dc '0-9')"
[ -z "$PORT" ] && PORT=$DEFAULT_PORT
[ -n "$WANT" ] && PORT="$WANT"

is_ours() {           # is the program (any version) answering on port $1?
  local r
  r="$(curl -s -m 2 "http://127.0.0.1:$1/api/ping" 2>/dev/null || true)"
  if echo "$r" | grep -q '"ok"' && echo "$r" | grep -q '"version"'; then return 0; fi
  r="$(curl -s -m 2 "http://127.0.0.1:$1/api/sync/status" 2>/dev/null || true)"     # versions before 1.2
  echo "$r" | grep -q '"running"' && echo "$r" | grep -q '"phase"'
}
listening_pids() { lsof -nP -iTCP:"$1" -sTCP:LISTEN -t 2>/dev/null || true; }
port_used() { [ -n "$(listening_pids "$1")" ]; }
who_uses() {
  local pid; pid="$(listening_pids "$1" | head -1)"
  [ -n "$pid" ] && ps -o comm= -p "$pid" 2>/dev/null | xargs basename 2>/dev/null || echo "another program"
}
stop_ours() {         # stop a running copy of this program (old or new) on port $1
  curl -s -m 2 -X POST "http://127.0.0.1:$1/api/quit" >/dev/null 2>&1 || true
  sleep 1
  for pid in $(listening_pids "$1"); do
    if ps -o command= -p "$pid" 2>/dev/null | grep -q "server.py"; then kill "$pid" 2>/dev/null || true; fi
  done
  sleep 1
}
free_port_from() {
  local p=$1
  while [ $p -lt $(( $1 + 200 )) ]; do
    if ! port_used $p; then echo $p; return; fi
    p=$((p + 1))
  done
  echo ""
}

if port_used "$PORT"; then
  if is_ours "$PORT"; then
    echo "Stopping the copy of the program that's already running on port $PORT..."
    stop_ours "$PORT"
  fi
fi
if port_used "$PORT"; then
  USER_OF="$(who_uses "$PORT")"
  SUGGEST="$(free_port_from $((PORT + 1)))"
  echo "Port $PORT is being used by another program ($USER_OF)."
  echo "The program needs a port of its own for its local web server (only this Mac can reach it)."
  if [ -t 0 ]; then
    while true; do
      read -r -p "Use port $SUGGEST instead? Press Return for yes, or type another port number (1024-65535): " ANS
      [ -z "$ANS" ] && ANS="$SUGGEST"
      if ! echo "$ANS" | grep -qE '^[0-9]+$' || [ "$ANS" -lt 1024 ] || [ "$ANS" -gt 65535 ]; then
        echo "  Please enter a number between 1024 and 65535."; continue; fi
      if port_used "$ANS" && ! is_ours "$ANS"; then echo "  Port $ANS is in use too - pick another."; continue; fi
      PORT="$ANS"; break
    done
  else
    PORT="$SUGGEST"
    echo "Using port $PORT instead."
  fi
fi
echo "$PORT" > "$PORT_FILE"
echo "Web server port: $PORT  (saved - the app and future installs will use it)"
echo

# ---------------------------------------------------------------- app bundle
echo "Installing..."
mkdir -p "$HOME/Applications"
# Build the new app beside the old one and swap it in at the end, so an interrupted
# install never leaves a half-built app behind.
FINAL="$APP"
APP="$HOME/Applications/.ap30sync-installing.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/app/web"
cp -X "$SRC/engine.py" "$SRC/server.py" "$SRC/updater.py" "$APP/Contents/Resources/app/"
cp -X "$SRC/web/index.html" "$APP/Contents/Resources/app/web/"
[ -f "$SRC/LICENSE.txt" ] && cp -X "$SRC/LICENSE.txt" "$APP/Contents/Resources/"
[ -f "$SRC/web/logo.png" ] && cp -X "$SRC/web/logo.png" "$APP/Contents/Resources/app/web/"
for m in "$SRC"/*Manual*.pdf; do [ -f "$m" ] && cp -X "$m" "$APP/Contents/Resources/app/web/manual.pdf"; done

cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>Epsilon's AP30 Music Boy Sync</string>
  <key>CFBundleDisplayName</key><string>Epsilon's AP30 Music Boy Sync</string>
  <key>CFBundleIdentifier</key><string>com.epsilonsworld.ap30musicboysync</string>
  <key>CFBundleVersion</key><string>3.1.2.1</string>
  <key>CFBundleShortVersionString</key><string>3.1.2.1</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>launcher</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>NSHumanReadableCopyright</key><string>© 2026 Steven Jeffery (AKA Epsilon) / EpsilonsWorld.com. Freeware - no warranty, use at your own risk.</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST

cat > "$APP/Contents/MacOS/launcher" <<'LAUNCH'
#!/bin/bash
# Opens Epsilon's AP30 Music Boy Sync. The engine runs inside a Terminal window, because
# Terminal already has macOS permission to read your music, Downloads folder and the card.
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
DIR="$(cd "$(dirname "$0")/../Resources/app" && pwd)"
DATA="$HOME/Library/Application Support/AP30 Sync"
PORT="$(cat "$DATA/port" 2>/dev/null | tr -dc '0-9')"; [ -z "$PORT" ] && PORT=8730

listening_pids() { lsof -nP -iTCP:"$1" -sTCP:LISTEN -t 2>/dev/null || true; }
is_ours() {
  local r; r="$(curl -s -m 2 "http://127.0.0.1:$1/api/ping" 2>/dev/null || true)"
  if echo "$r" | grep -q '"ok"' && echo "$r" | grep -q '"version"'; then return 0; fi
  r="$(curl -s -m 2 "http://127.0.0.1:$1/api/sync/status" 2>/dev/null || true)"
  echo "$r" | grep -q '"running"' && echo "$r" | grep -q '"phase"'
}

# Already running and answering? Just bring the window back.
if is_ours "$PORT"; then open "http://127.0.0.1:$PORT/"; exit 0; fi

PIDS="$(listening_pids "$PORT")"
if [ -n "$PIDS" ]; then
  # A stuck copy of this program? Stop it. Anything else is left alone.
  OURS=""
  for pid in $PIDS; do ps -o command= -p "$pid" 2>/dev/null | grep -q "server.py" && OURS="$OURS $pid"; done
  if [ -n "$OURS" ]; then kill $OURS 2>/dev/null; sleep 1; kill -9 $OURS 2>/dev/null; fi
fi
if [ -n "$(listening_pids "$PORT")" ]; then
  WHO="$(ps -o comm= -p "$(listening_pids "$PORT" | head -1)" 2>/dev/null | xargs basename 2>/dev/null)"
  NEW=$((PORT + 1)); while [ -n "$(listening_pids $NEW)" ] && [ $NEW -lt $((PORT + 200)) ]; do NEW=$((NEW + 1)); done
  ANSWER="$(osascript -e "display dialog \"Port $PORT is being used by another program (${WHO:-unknown}).\n\nEpsilon's AP30 Music Boy Sync needs a port of its own for its local web server. Use port $NEW instead? (It will be remembered.)\" buttons {\"Cancel\", \"Use port $NEW\"} default button 2 with icon caution with title \"Epsilon's AP30 Music Boy Sync\"" 2>/dev/null)"
  case "$ANSWER" in *"Use port"*) PORT=$NEW; mkdir -p "$DATA"; echo "$PORT" > "$DATA/port";; *) exit 0;; esac
fi

open -a Terminal "$DIR/run.command"
LAUNCH
chmod +x "$APP/Contents/MacOS/launcher"

cat > "$APP/Contents/Resources/app/run.command" <<'RUN'
#!/bin/bash
# Epsilon's AP30 Music Boy Sync engine - keep this window open while you use the program.
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
cd "$(dirname "$0")"
printf '\033]0;Epsilon'"'"'s AP30 Music Boy Sync\007'
LOG="$HOME/Library/Logs/Epsilon's AP30 Music Boy Sync.log"
DATA="$HOME/Library/Application Support/AP30 Sync"
export AP30SYNC_PORT="$(cat "$DATA/port" 2>/dev/null | tr -dc '0-9')"; [ -z "$AP30SYNC_PORT" ] && export AP30SYNC_PORT=8730
PY=""
for cand in "$(/bin/zsh -lc 'command -v python3' 2>/dev/null)" \
            /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
            /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
  if [ -n "$cand" ] && [ -x "$cand" ] && "$cand" -c "import mutagen" >/dev/null 2>&1; then PY="$cand"; break; fi
done
clear
echo "============ Epsilon's AP30 Music Boy Sync ============"
echo " by Epsilon / EpsilonsWorld.com, with the assistance of Claude AI"
echo
if [ -z "$PY" ]; then
  echo "The program needs the Python 'mutagen' module. Run:"
  echo "    python3 -m pip install --user mutagen"
  echo "then open the program again."
  read -r -p "Press Return to close." _
  exit 1
fi
echo "Using $PY on port $AP30SYNC_PORT"
echo "--- $(date) starting with $PY on port $AP30SYNC_PORT" >> "$LOG"
"$PY" -u server.py 2>&1 | tee -a "$LOG"
echo
echo "The program has stopped. You can close this window."
RUN
chmod +x "$APP/Contents/Resources/app/run.command"

# App icon (the Epsilon logo if supplied, otherwise the music-note icon)
ICON_SRC="$SRC/icon.png"
if [ -f "$ICON_SRC" ] && command -v iconutil >/dev/null 2>&1; then
  ICONSET="$(mktemp -d)/AppIcon.iconset"
  mkdir -p "$ICONSET"
  for s in 16 32 128 256 512; do
    sips -z $s $s "$ICON_SRC" --out "$ICONSET/icon_${s}x${s}.png" >/dev/null 2>&1
    d=$((s*2)); sips -z $d $d "$ICON_SRC" --out "$ICONSET/icon_${s}x${s}@2x.png" >/dev/null 2>&1
  done
  iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AppIcon.icns" 2>/dev/null || true
fi

xattr -cr "$APP" 2>/dev/null || true
# Give the app a local ("ad-hoc") signature. Without any signature, macOS can hold a rebuilt
# app at launch for a security check (the icon just bounces); with one it opens normally.
if command -v codesign >/dev/null 2>&1; then
  codesign --force --deep --sign - "$APP" >/dev/null 2>&1 && echo "Signed the app (ad-hoc, on this Mac)." || echo "Note: couldn't sign the app (codesign failed) - it should still open."
fi
rm -rf "$FINAL"
mv "$APP" "$FINAL"
APP="$FINAL"
if [ -d "$OLD_APP" ]; then rm -rf "$OLD_APP"; echo "Removed the old 'AP30 Sync' app (your settings and playlists are kept)."; fi
touch "$APP"

echo
echo "Installed: $APP"
echo
echo "Checking the tools it uses:"
ok=1
PYM=""
for cand in "$(/bin/zsh -lc 'command -v python3' 2>/dev/null)" /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
  if [ -n "$cand" ] && [ -x "$cand" ] && "$cand" -c "import mutagen" >/dev/null 2>&1; then PYM="$cand"; break; fi
done
if [ -n "$PYM" ]; then echo "  ✓ python3 with mutagen ($PYM)"; else echo "  ✗ mutagen missing:  python3 -m pip install --user mutagen"; ok=0; fi
# A tool only counts if it actually runs: old PowerPC / 32-bit Intel copies left behind by earlier
# macOS upgrades look installed but fail with "bad CPU type in executable".
BROKEN=""
find_working() {   # prints the first copy of any named program that runs
  local name p
  for name in "$@"; do
    for p in $(which -a "$name" 2>/dev/null | awk '!seen[$0]++'); do
      if "$p" -version >/dev/null 2>&1; then echo "$p"; return 0; fi
      BROKEN="$BROKEN $p"
    done
  done
  return 1
}
IM=$(find_working magick convert) || IM=""
FF=$(find_working ffmpeg) || FF=""
# (run again outside the subshells to collect the broken copies for the message below)
find_working magick convert >/dev/null; find_working ffmpeg >/dev/null
if [ -n "$IM" ]; then echo "  ✓ ImageMagick ($IM)"; else echo "  ✗ ImageMagick missing:  brew install imagemagick"; ok=0; fi
if [ -n "$FF" ]; then echo "  ✓ ffmpeg ($FF)"; else echo "  - ffmpeg not installed (only needed for Compact MP3 playlists):  brew install ffmpeg"; fi
if [ -n "$BROKEN" ]; then
  echo
  echo "  ! These copies are on your Mac but won't run (old PowerPC/Intel versions left over"
  echo "    from an earlier Mac or macOS). The program ignores them:"
  for p in $BROKEN; do echo "      $p  ($(file -b "$p" 2>/dev/null | cut -c1-60))"; done
  echo "    To tidy up, see \"Old programs left on your Mac\" in the manual."
fi
echo
if [ $ok = 1 ] || [ "$AP30SYNC_UPDATE" = "1" ]; then
  echo "Opening $NAME... (also in your Applications folder and Launchpad)"
  open "$APP"
else
  echo "Install the missing tools above, then open $NAME from your Applications folder."
fi
