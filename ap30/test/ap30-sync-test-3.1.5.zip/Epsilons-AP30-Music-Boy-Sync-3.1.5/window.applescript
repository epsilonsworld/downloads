-- Epsilon's AP30 Music Boy Sync: tidy the program's own Terminal windows.
-- osascript window.applescript minimize|close /dev/ttysNNN
-- "close" only closes a window with nothing running in it, so Terminal never asks and a
-- window that is running the program is never touched.
on run argv
	set act to item 1 of argv
	set t to item 2 of argv
	tell application "Terminal"
		repeat with wid in (get id of every window)
			try
				set w to window id wid
				if tty of selected tab of w is t then
					if act is "close" then
						if not (busy of selected tab of w) then close w
					else if act is "minimize" then
						set miniaturized of w to true
					end if
				end if
			end try
		end repeat
	end tell
end run
