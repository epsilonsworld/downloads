#!/usr/bin/env python3
"""
Epsilon's AP30 Music Boy Sync - local server. Runs only on this Mac (127.0.0.1);
the app's window opens in your web browser. Start it with the app icon: it runs this
inside Terminal, which already has macOS permission to read your music,
Downloads folder and the card.
"""

import json
import os
import sys
import threading
import time
import traceback
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine  # noqa: E402
import updater  # noqa: E402
from engine import Blocked, fs_call  # noqa: E402

APP_NAME = "Epsilon's AP30 Music Boy Sync"
APP_ID = "epsilons-ap30-music-boy-sync"
APP_VERSION = "3.1.7"
APP_AUTHOR = "Epsilon (AKA Steven Jeffery) / EpsilonsWorld.com, with the assistance of Claude AI"
APP_AUTHOR_SHORT = "Epsilon / EpsilonsWorld.com, with the assistance of Claude AI"
APP_URL = "https://www.epsilonsworld.com"
DEFAULT_PORT = 8730


def configured_port():
    """The port chosen at install time (saved in the app's data folder), or 8730."""
    if os.environ.get("AP30SYNC_PORT"):
        return int(os.environ["AP30SYNC_PORT"])
    try:
        with open(os.path.join(engine.APP_DIR, "port")) as fh:
            p = int(fh.read().strip())
            if 1024 <= p <= 65535:
                return p
    except (OSError, ValueError):
        pass
    return DEFAULT_PORT


PORT = configured_port()
LAST_SEEN = [0.0]          # when the page last asked for something
WEB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
AUDIO_TYPES = {".flac": "audio/flac", ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".aac": "audio/aac",
               ".wav": "audio/wav", ".aif": "audio/aiff", ".aiff": "audio/aiff", ".ogg": "audio/ogg",
               ".opus": "audio/ogg"}

store = engine.Store()
library = engine.Library()
itunes = engine.ITunes()
syncer = engine.Syncer()
planner = {"running": False, "phase": "", "done": 0, "total": 0, "result": None, "plan": None}
plan_lock = threading.Lock()


def log(msg):
    sys.stderr.write(time.strftime("%H:%M:%S ") + msg + "\n")
    sys.stderr.flush()


updates = updater.Updater(engine.APP_DIR, APP_VERSION, engine.which, log)


def clean_path(p):
    p = str(p or "").strip().strip('"').strip("'").strip()
    return os.path.expanduser(p) if p else p


def public_plan(p):
    return {k: v for k, v in p.items() if not k.startswith("_")}


def list_dir(path, want_files):
    home = os.path.expanduser("~")
    path = os.path.abspath(clean_path(path) or home)
    places = [{"name": "Home", "path": home}, {"name": "Music", "path": os.path.join(home, "Music")},
              {"name": "Downloads", "path": os.path.join(home, "Downloads")},
              {"name": "Desktop", "path": os.path.join(home, "Desktop")}]
    try:
        vols = fs_call(os.listdir, "/Volumes", timeout=3) if os.path.isdir("/Volumes") else []
        for v in sorted(vols):
            if not v.startswith(".") and v != "Macintosh HD":
                places.append({"name": "💾 " + v, "path": os.path.join("/Volumes", v)})
    except (Blocked, OSError):
        pass
    out = {"path": path, "parent": os.path.dirname(path) if os.path.dirname(path) != path else None,
           "dirs": [], "files": [], "places": places, "error": ""}
    try:
        if not fs_call(os.path.isdir, path, timeout=4):
            out["error"] = "That folder doesn't exist."
            return out
        names = fs_call(os.listdir, path, timeout=6)
    except Blocked:
        out["error"] = ("macOS isn't letting the app look inside this folder. Start it from its app icon "
                        "(it runs in Terminal). If it still happens: System Settings › Privacy & Security › "
                        "Files and Folders › Terminal, and turn this folder on.")
        return out
    except OSError as e:
        out["error"] = str(e)
        return out
    for n in sorted(names, key=str.lower):
        if n.startswith("."):
            continue
        full = os.path.join(path, n)
        try:
            if os.path.isdir(full):
                out["dirs"].append(n)
            elif want_files and n.lower().endswith(".xml"):
                out["files"].append(n)
        except OSError:
            pass
    return out


def allowed_audio(path):
    if path in library.tracks:
        return True
    for p in itunes.playlists:
        for t in p["tracks"]:
            if t["path"] == path:
                return True
    return False


def run_plan():
    def progress(phase, done, total):
        planner.update(phase=phase, done=done, total=total)
    try:
        itunes.load(store.config["library_xml"])
        p = engine.make_plan(store, library, itunes, progress)
        planner["plan"] = p
        planner["result"] = public_plan(p)
    except Exception as e:
        log("plan failed\n" + traceback.format_exc())
        planner["result"] = {"ok": False, "error": f"Checking the card failed: {e}"}
    finally:
        planner["running"] = False


class Handler(BaseHTTPRequestHandler):
    server_version = "AP30Sync"
    protocol_version = "HTTP/1.1"          # Safari's audio player expects 1.1 range streaming

    def log_message(self, fmt, *args):
        pass

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, data, ctype, cache=True):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "max-age=86400" if cache else "no-store")
        self.end_headers()
        self.wfile.write(data)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode())
        except ValueError:
            return {}

    def local_only(self):
        return (self.headers.get("Host") or "").split(":")[0] in ("127.0.0.1", "localhost")

    # every request is wrapped so errors reach the log and the window, never a silent hang
    def do_GET(self):
        self._safe(self._get)

    def do_POST(self):
        t = time.time()
        self._safe(self._post)
        log(f"POST {urllib.parse.urlparse(self.path).path} {int((time.time() - t) * 1000)} ms")

    def _safe(self, fn):
        try:
            if not self.local_only():
                return self.send_error(403)
            fn()
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Blocked as e:
            log(f"BLOCKED {self.command} {self.path}: {e}")
            try:
                self.send_json({"ok": False, "error": str(e)}, 503)
            except Exception:
                pass
        except Exception as e:
            log(f"ERROR {self.command} {self.path}\n{traceback.format_exc()}")
            try:
                self.send_json({"ok": False, "error": f"{type(e).__name__}: {e}"}, 500)
            except Exception:
                pass

    def send_audio(self, path):
        ctype = AUDIO_TYPES.get(os.path.splitext(path)[1].lower(), "application/octet-stream")
        size = fs_call(os.path.getsize, path)
        start, end = 0, size - 1
        rng = self.headers.get("Range")
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].split(",")[0].partition("-")
            if a.strip():
                start = int(a)
                if b.strip():
                    end = min(int(b), size - 1)
            elif b.strip():
                start = max(0, size - int(b))
            if start > end or start >= size:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        else:
            self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        with open(path, "rb") as fh:
            fh.seek(start)
            left = end - start + 1
            while left > 0:
                chunk = fh.read(min(262144, left))
                if not chunk:
                    break
                self.wfile.write(chunk)
                left -= len(chunk)

    def _get(self):
        u = urllib.parse.urlparse(self.path)
        LAST_SEEN[0] = time.time()
        q = urllib.parse.parse_qs(u.query)
        arg = lambda k, d="": (q.get(k) or [d])[0]
        if u.path in ("/", "/index.html"):
            with open(os.path.join(WEB, "index.html"), "rb") as fh:
                return self.send_bytes(fh.read(), "text/html; charset=utf-8", cache=False)
        if u.path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if u.path == "/api/ping":
            return self.send_json({"ok": True, "app": APP_ID, "name": APP_NAME, "version": APP_VERSION})
        if u.path == "/api/about":
            return self.send_json({"name": APP_NAME, "version": APP_VERSION, "author": APP_AUTHOR, "url": APP_URL,
                                   "port": PORT, "data": engine.APP_DIR, "tools": engine.tools(),
                                   "python": sys.version.split()[0],
                                   "manual": os.path.isfile(os.path.join(WEB, "manual.pdf")),
                                   "logo": os.path.isfile(os.path.join(WEB, "logo.png"))})
        if u.path in ("/logo.png", "/manual.pdf"):
            f = os.path.join(WEB, u.path.lstrip("/"))
            if not os.path.isfile(f):
                return self.send_error(404)
            with open(f, "rb") as fh:
                return self.send_bytes(fh.read(), "image/png" if f.endswith(".png") else "application/pdf")
        if u.path == "/api/state":
            itunes.ensure(store.config["library_xml"])
            excl = {x.lower() for x in store.config.get("itunes_excluded", [])}
            return self.send_json({
                "version": APP_VERSION, "app_name": APP_NAME, "config": store.config, "playlists": store.playlists,
                "tools": engine.tools(), "library": library.status, "track_count": len(library.tracks),
                "itunes": {"error": itunes.error, "xml": itunes.xml, "loading": itunes.loading, "playlists": [
                    {"name": p["name"], "smart": p["smart"], "excluded": p["name"].lower() in excl,
                     "tracks": sum(1 for t in p["tracks"] if t["path"]),
                     "skipped": sum(1 for t in p["tracks"] if not t["path"]),
                     "bytes": sum(t["size"] for t in p["tracks"] if t["path"])}
                    for p in itunes.playlists]},
                "sync": {k: v for k, v in syncer.status.items() if k != "log"},
                "plan": {k: planner[k] for k in ("running", "phase", "done", "total")}})
        if u.path == "/api/library":
            keys = ["path", "title", "artist", "album", "albumartist", "year", "track", "disc",
                    "duration", "size", "art_bytes"]
            rows = [[t.get(k) for k in keys] for t in library.listing()]
            return self.send_json({"keys": keys, "rows": rows, "status": library.status})
        if u.path == "/api/ls":
            return self.send_json(list_dir(arg("path"), arg("files", "0") == "1"))
        if u.path == "/api/itunes":
            for p in itunes.playlists:
                if p["name"] == arg("name"):
                    return self.send_json({"name": p["name"], "tracks": p["tracks"]})
            return self.send_json({"error": "not found", "loading": itunes.loading}, 404)
        if u.path == "/api/art":
            path = arg("path")
            try:
                meta = ({"artist": arg("artist"), "album": arg("album"), "title": arg("title"), "pid": arg("pid")}
                        if (arg("artist") or arg("pid")) else None)
                data = fs_call(engine.thumbnail, path, 96, meta, timeout=8) if path else None
            except (Blocked, OSError):
                data = None
            if not data:
                return self.send_error(404)
            return self.send_bytes(data, "image/jpeg")
        if u.path == "/api/audio":
            path = arg("path")
            if not path or not allowed_audio(path):
                return self.send_error(404)
            return self.send_audio(path)
        if u.path == "/api/update":
            # on launch the page asks once; the site is contacted at most once a day unless forced
            force = arg("force", "0") == "1"
            if not force and not store.config.get("check_updates", True):
                return self.send_json({"available": False, "disabled": True, "current": APP_VERSION})
            return self.send_json(updates.check(force=force))
        if u.path == "/api/update/status":
            return self.send_json(dict(updates.status, current=APP_VERSION))
        if u.path == "/api/plan/status":
            return self.send_json({k: planner[k] for k in ("running", "phase", "done", "total", "result")})
        if u.path == "/api/sync/status":
            return self.send_json(syncer.status)
        return self.send_error(404)

    def _post(self):
        u = urllib.parse.urlparse(self.path)
        b = self.body()
        if u.path == "/api/config":
            for k in ("library_xml", "card"):
                if k in b:
                    b[k] = clean_path(b[k])
            if "flac_folders" in b:
                b["flac_folders"] = [clean_path(f) for f in b["flac_folders"] if clean_path(f)]
            store.save_config(b)
            saved = engine.load_json(store.cfg_path, {})
            ok = all(saved.get(k) == v for k, v in b.items() if k in engine.DEFAULT_CONFIG)
            warn = []
            if b.get("card"):
                st = engine.folder_status(b["card"])
                if st == "missing":
                    warn.append(f"The card isn't at {b['card']} right now (fine if it isn't inserted).")
                elif st == "blocked":
                    warn.append(f"macOS is blocking access to {b['card']}.")
            if b.get("library_xml"):
                try:
                    if not fs_call(os.path.isfile, b["library_xml"], timeout=3):
                        warn.append(f"There's no file at {b['library_xml']}.")
                except Blocked:
                    warn.append(f"macOS is blocking access to {b['library_xml']}.")
            for f in b.get("flac_folders", []):
                st = engine.folder_status(f)
                if st != "ok":
                    warn.append(f"{'Folder not found' if st == 'missing' else 'macOS is blocking access to'}: {f}")
            log(f"settings saved ok={ok} {json.dumps(b, ensure_ascii=False)}")
            if "library_xml" in b:
                itunes.ensure(store.config["library_xml"])
            return self.send_json({"ok": ok, "config": store.config, "warnings": warn,
                                   "error": "" if ok else f"Could not write {store.cfg_path}"})
        if u.path == "/api/log":
            log("browser: " + str(b.get("message", ""))[:2000])
            return self.send_json({"ok": True})
        if u.path == "/api/playlists":
            store.save_playlists(b.get("playlists", []))
            return self.send_json({"ok": True})
        if u.path == "/api/library/rescan":
            folders = store.config.get("flac_folders", [])
            if not folders:
                return self.send_json({"ok": False, "error": "Add a FLAC library folder first."})
            library.scan(folders)
            return self.send_json({"ok": True})
        if u.path == "/api/itunes/exclude":
            names = set(store.config.get("itunes_excluded", []))
            for n in b.get("names", []):
                (names.add if b.get("excluded") else names.discard)(n)
            store.save_config({"itunes_excluded": sorted(names)})
            return self.send_json({"ok": True})
        if u.path == "/api/itunes/match_card":
            # include exactly the iTunes playlists that already have a folder on the card
            root = os.path.join(engine.expand(store.config["card"]), engine.fat_name(store.config["itunes_root"]))
            try:
                on_card = {n.lower() for n in fs_call(os.listdir, root, timeout=8)}
            except (Blocked, OSError):
                return self.send_json({"ok": False, "error": f"Couldn't read {root} - is the card inserted?"})
            itunes.load(store.config["library_xml"])
            excl = [p["name"] for p in itunes.playlists if engine.fat_name(p["name"]).lower() not in on_card]
            store.save_config({"itunes_excluded": sorted(excl)})
            return self.send_json({"ok": True, "included": len(itunes.playlists) - len(excl), "excluded": len(excl)})
        if u.path == "/api/itunes/fetch_art":
            # preview: ask the Music app for artwork of this playlist's tracks that have none in the file
            for p in itunes.playlists:
                if p["name"] == b.get("name"):
                    pids = [t["pid"] for t in p["tracks"] if t.get("path") and t.get("pid") and not t.get("art_count")]
                    got = engine.fetch_music_art(pids, log) if pids else 0
                    return self.send_json({"ok": True, "asked": len(pids), "got": got})
            return self.send_json({"ok": False, "error": "not found"})
        if u.path == "/api/itunes/reload":
            itunes.ensure(store.config["library_xml"], force=True)
            return self.send_json({"ok": not itunes.error, "error": itunes.error, "loading": itunes.loading})
        if u.path == "/api/plan":
            if syncer.status["running"]:
                return self.send_json({"ok": False, "error": "A sync is running."})
            with plan_lock:
                if not planner["running"]:
                    planner.update(running=True, phase="Starting", done=0, total=0, result=None)
                    threading.Thread(target=run_plan, daemon=True).start()
            return self.send_json({"ok": True, "started": True})
        if u.path == "/api/sync/start":
            p = planner.get("plan")
            if not p or not p.get("ok") or planner["running"]:
                return self.send_json({"ok": False, "error": "Press Check card first."})
            if p["final_used"] > p["card"]["total"]:
                return self.send_json({"ok": False, "error": "Not enough space on the card."})
            if p["final_used"] > p["limit"] and not b.get("ignore_limit"):
                return self.send_json({"ok": False, "error": "Over the AP30 library limit.", "over_limit": True})
            if p["tracks_after"] > p["track_limit"] and not b.get("ignore_tracks"):
                return self.send_json({"ok": False, "error": "Over the AP30 track limit.", "over_tracks": True,
                                       "tracks_after": p["tracks_after"], "track_limit": p["track_limit"]})
            planner["plan"] = None                  # a plan is used once; check again after syncing
            return self.send_json({"ok": syncer.start(store, p)})
        if u.path == "/api/update/install":
            if syncer.status["running"] or planner["running"]:
                return self.send_json({"ok": False, "error": "Wait until the sync or card check has finished."})
            ok, err = updates.start_install(lambda: store.save_playlists(store.playlists))
            return self.send_json({"ok": ok, "error": err})
        if u.path == "/api/sync/cancel":
            syncer.cancel = True
            return self.send_json({"ok": True})
        if u.path == "/api/eject":
            import subprocess
            card = engine.expand(store.config["card"])
            r = subprocess.run(["diskutil", "eject", card], capture_output=True, text=True, timeout=60)
            return self.send_json({"ok": r.returncode == 0, "message": (r.stdout or r.stderr).strip()})
        if u.path == "/api/quit":
            self.send_json({"ok": True})
            log("Quit requested")
            threading.Thread(target=lambda: (time.sleep(0.3), os._exit(0)), daemon=True).start()
            return
        return self.send_error(404)


def main():
    url = f"http://127.0.0.1:{PORT}/"
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        log(f"Port {PORT} is already in use. If it's {APP_NAME}, its window opens now; "
            f"otherwise run install.sh again to choose another port.")
        webbrowser.open(url)
        return
    srv.daemon_threads = True
    log(f"{APP_NAME} {APP_VERSION} running at {url}")
    log(f"By {APP_AUTHOR_SHORT} - {APP_URL}")
    log(f"Settings and playlists: {engine.APP_DIR}")
    if updates.channel == "test":
        log("Update channel: TEST (reads ap30/latest-test.json) - delete update-channel in the settings folder to go back")
    log("Keep this window open while you use the app. Close it (or press Ctrl-C) to stop.")
    if store.config.get("flac_folders"):
        library.scan(store.config["flac_folders"])
    itunes.ensure(store.config["library_xml"])
    flag = os.path.join(engine.APP_DIR, ".updating")
    if os.path.exists(flag):
        # just updated: the open page reloads itself; open a new one only if no page comes back
        try:
            os.remove(flag)
        except OSError:
            pass
        log(f"Updated to version {APP_VERSION}.")

        def reopen():
            start = time.time()
            time.sleep(10)
            if LAST_SEEN[0] < start:
                webbrowser.open(url)
        threading.Thread(target=reopen, daemon=True).start()
    elif "--no-browser" not in sys.argv:
        threading.Thread(target=lambda: (time.sleep(0.6), webbrowser.open(url)), daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log("Stopped.")


if __name__ == "__main__":
    main()
