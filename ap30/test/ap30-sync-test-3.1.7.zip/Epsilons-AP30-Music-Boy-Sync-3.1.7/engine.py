"""
Epsilon's AP30 Music Boy Sync - engine: library index, playlists, sync planning and syncing.

Nothing in your music library is ever modified. All changes (shrunk cover
art, playlist tags, MP3 conversion) are made to copies written to the card.
"""

import re
import hashlib
import json
import os
import plistlib
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unicodedata
import urllib.parse

VERSION = 1                      # bump to force re-generation of synced files
AUDIO = {".flac", ".mp3", ".m4a", ".aac", ".wav", ".aif", ".aiff", ".ogg", ".opus"}
FAT_BAD = '<>:"/\\|?*'
MANIFEST_DIR = ".ap30sync"
EXTRA_PATH = ["/opt/homebrew/bin", "/usr/local/bin", "/usr/bin", "/bin"]

APP_DIR = os.environ.get("AP30SYNC_HOME") or os.path.expanduser("~/Library/Application Support/AP30 Sync")
os.makedirs(os.path.join(APP_DIR, "thumbs"), exist_ok=True)

DEFAULT_CONFIG = {
    "flac_folders": [],
    "library_xml": "~/Downloads/Library.xml",
    "card": "/Volumes/MUSICBOY",
    "flac_root": "FLAC Playlists",
    "itunes_root": "iTunes Playlists",
    "art_size": 300,
    "retag": True,
    "limit_gb": 256,
    "track_limit": 7000,          # AP30 library: tracks past this are silently left out (estimate)
    "itunes_excluded": ["iPhone Playlist", "2008-2009 Songs"],
    "online_art": True,
    "flac_album_label": True,
    "check_updates": True,
}


# ---------------------------------------------------------------- helpers

class Blocked(Exception):
    """A disk access didn't answer - usually macOS privacy protection, or a sleeping/removed card."""


def fs_call(fn, *args, timeout=5):
    """Run a file-system call with a time limit so nothing in the app can hang forever."""
    box = {}

    def run():
        try:
            box["v"] = fn(*args)
        except BaseException as e:          # noqa: BLE001
            box["e"] = e
    t = threading.Thread(target=run, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        where = args[0] if args else ""
        raise Blocked(f"No answer from {where} - macOS may be blocking access to it, or the disk is asleep/removed.")
    if "e" in box:
        raise box["e"]
    return box.get("v")


def folder_status(path):
    """'ok', 'missing' or 'blocked' for a folder."""
    try:
        if not fs_call(os.path.isdir, path):
            return "missing"
        fs_call(os.listdir, path)
        return "ok"
    except Blocked:
        return "blocked"
    except PermissionError:
        return "blocked"
    except OSError:
        return "missing"


def which(name):
    for d in os.environ.get("PATH", "").split(os.pathsep) + EXTRA_PATH:
        p = os.path.join(d, name)
        if os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return None


_TOOLS_CACHE = {"at": 0.0, "value": None}


def _runs(path):
    """True if the program actually starts. Old PowerPC or 32-bit Intel copies left behind by
    earlier macOS upgrades exist and look executable, but fail with "Bad CPU type in executable"."""
    try:
        r = subprocess.run([path, "-version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=20)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _working(names, broken):
    """First copy of any of these programs that really runs. Homebrew's folders are tried first."""
    seen = set()
    dirs = ["/opt/homebrew/bin"] + os.environ.get("PATH", "").split(os.pathsep) + EXTRA_PATH
    for name in names:
        for d in dirs:
            p = os.path.join(d, name)
            real = os.path.realpath(p)
            if real in seen or not (os.path.isfile(p) and os.access(p, os.X_OK)):
                continue
            seen.add(real)
            if _runs(p):
                return p
            broken.append(p)
    return None


def tools():
    """Which helper programs work. Checked at most once a minute (installing one is picked up)."""
    now = time.time()
    if _TOOLS_CACHE["value"] and now - _TOOLS_CACHE["at"] < 60:
        return _TOOLS_CACHE["value"]
    try:
        import mutagen  # noqa: F401
        mut = True
    except ImportError:
        mut = False
    broken = []
    value = {"mutagen": mut, "imagemagick": _working(["magick", "convert"], broken),
             "ffmpeg": _working(["ffmpeg"], broken), "broken": broken}
    _TOOLS_CACHE.update(at=now, value=value)
    return value


def nfc(text):
    """One canonical form for names. macOS can list a name like 'Björk' in a different (decomposed)
    Unicode form from the one it was created with - compare names only in this form."""
    return unicodedata.normalize("NFC", text)


def on_disk(path):
    """The spelling of path that actually opens on this disk (tries both Unicode forms)."""
    for form in (path, unicodedata.normalize("NFC", path), unicodedata.normalize("NFD", path)):
        if os.path.lexists(form):
            return form
    return path


def exact_name(path):
    """The exact spelling a file has on the card, taken from its folder listing.
    macOS opens a file on a FAT32 card by either Unicode spelling of its name, but only deletes or
    renames it when given the exact stored spelling - so look that up before deleting/renaming."""
    d, n = os.path.split(path)
    try:
        for e in os.listdir(d or "."):
            if e == n:
                return path
        target = nfc(n)
        for e in os.listdir(d or "."):
            if nfc(e) == target:
                return os.path.join(d, e)
    except OSError:
        pass
    return path


def remove_exact(path):
    """Delete a file on the card by its exact stored name, trying every spelling."""
    tried = []
    for p in (exact_name(path), path, unicodedata.normalize("NFD", path), unicodedata.normalize("NFC", path)):
        if p in tried:
            continue
        tried.append(p)
        try:
            os.remove(p)
            return True
        except FileNotFoundError:
            continue
    if os.path.basename(path).startswith("._"):
        return True            # macOS removes a file's "._" companion itself when the file is deleted
    raise FileNotFoundError(f"Couldn't delete {path} under any spelling of its name")


def fat_name(part, maxlen=150):
    part = unicodedata.normalize("NFC", str(part))
    part = "".join("_" if (c in FAT_BAD or ord(c) < 32) else c for c in part)
    part = part.strip().rstrip(" .") or "_"
    if len(part) > maxlen:
        root, ext = os.path.splitext(part)
        part = root[: maxlen - len(ext)].rstrip(" .") + ext
    return part


def expand(p):
    return os.path.abspath(os.path.expanduser(p)) if p else p


def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False)
    os.replace(tmp, path)


# ---------------------------------------------------------------- config / playlists

class Store:
    def __init__(self):
        self.cfg_path = os.path.join(APP_DIR, "config.json")
        self.pl_path = os.path.join(APP_DIR, "playlists.json")
        self.lock = threading.Lock()
        self.config = dict(DEFAULT_CONFIG)
        self.config.update(load_json(self.cfg_path, {}))
        self.playlists = load_json(self.pl_path, [])

    def save_config(self, updates):
        with self.lock:
            for k, v in updates.items():
                if k in DEFAULT_CONFIG:
                    self.config[k] = v
            save_json(self.cfg_path, self.config)

    def save_playlists(self, pls):
        clean = []
        for p in pls:
            clean.append({"id": str(p.get("id") or time.time()),
                          "name": str(p.get("name") or "Untitled").strip() or "Untitled",
                          "mode": "mp3" if p.get("mode") == "mp3" else "copy",
                          "tracks": [str(t) for t in p.get("tracks", [])]})
        with self.lock:
            self.playlists = clean
            save_json(self.pl_path, clean)


# ---------------------------------------------------------------- tags and art

def read_tags(path):
    """Return a dict of display tags, duration, art size."""
    meta = {"title": "", "artist": "", "album": "", "albumartist": "", "year": "",
            "track": 0, "disc": 0, "duration": 0.0, "art_bytes": 0}
    try:
        import mutagen
        ext = os.path.splitext(path)[1].lower()
        if ext == ".flac":
            from mutagen.flac import FLAC
            f = FLAC(path)
            tags = f.tags or {}
            g = lambda k: (tags.get(k) or [""])[0]
            meta["art_bytes"] = sum(len(p.data) for p in f.pictures)
        else:
            f = mutagen.File(path, easy=True)
            tags = (f.tags if f is not None else None) or {}
            g = lambda k: (tags.get(k) or [""])[0] if hasattr(tags, "get") else ""
            raw = mutagen.File(path)
            if raw is not None and raw.tags is not None:
                if hasattr(raw.tags, "getall"):
                    meta["art_bytes"] = sum(len(a.data) for a in raw.tags.getall("APIC"))
                elif "covr" in raw.tags:
                    meta["art_bytes"] = sum(len(bytes(c)) for c in raw.tags["covr"])
        meta["title"] = g("title")
        meta["artist"] = g("artist")
        meta["album"] = g("album")
        meta["albumartist"] = g("albumartist") or g("album artist")
        meta["year"] = str(g("date") or g("year"))[:4]
        for key, field in (("tracknumber", "track"), ("discnumber", "disc")):
            v = str(g(key)).split("/")[0].strip()
            meta[field] = int(v) if v.isdigit() else 0
        if f is not None and getattr(f, "info", None) is not None:
            meta["duration"] = float(getattr(f.info, "length", 0) or 0)
    except Exception:
        pass
    if not meta["title"]:
        meta["title"] = os.path.splitext(os.path.basename(path))[0]
    return meta


def embedded_art(path):
    """Return the front cover bytes embedded in a file, or None."""
    try:
        ext = os.path.splitext(path)[1].lower()
        if ext == ".flac":
            from mutagen.flac import FLAC
            pics = FLAC(path).pictures
            if pics:
                return next((p for p in pics if p.type == 3), pics[0]).data
        elif ext == ".mp3":
            from mutagen.id3 import ID3
            ap = ID3(path).getall("APIC")
            if ap:
                return next((a for a in ap if a.type == 3), ap[0]).data
        elif ext in (".m4a", ".aac"):
            from mutagen.mp4 import MP4
            covr = (MP4(path).tags or {}).get("covr")
            if covr:
                return bytes(covr[0])
    except Exception:
        pass
    return None


COVER_NAMES = ["cover.jpg", "cover.jpeg", "cover.png", "folder.jpg", "folder.jpeg", "folder.png",
               "Cover.jpg", "Folder.jpg", "front.jpg"]


_dir_art = {}


def folder_art(folder):
    """Cover art for an album folder: a cover/folder image, or art embedded in any of its tracks."""
    if folder in _dir_art:
        return _dir_art[folder]
    data = None
    try:
        names = sorted(os.listdir(folder))
        for n in names:
            if n in COVER_NAMES or n.lower() in ("cover.jpg", "cover.png", "folder.jpg", "folder.png", "front.jpg", "albumart.jpg"):
                with open(os.path.join(folder, n), "rb") as fh:
                    data = fh.read()
                break
        if not data:                                 # multi-disc albums: cover.jpg one folder up
            parent = os.path.dirname(folder.rstrip(os.sep))
            try:
                for n in sorted(os.listdir(parent)):
                    if n.lower() in ("cover.jpg", "cover.png", "folder.jpg", "folder.png", "front.jpg"):
                        with open(os.path.join(parent, n), "rb") as fh:
                            data = fh.read()
                        break
            except OSError:
                pass
        if not data:
            for n in names[:60]:
                if n.startswith("._") or os.path.splitext(n)[1].lower() not in AUDIO | {".m4p"}:
                    continue
                data = embedded_art(os.path.join(folder, n))
                if data:
                    break
    except OSError:
        pass
    if len(_dir_art) > 5000:
        _dir_art.clear()
    _dir_art[folder] = data
    return data


def _norm(x):
    return "".join(ch for ch in unicodedata.normalize("NFKD", str(x or "").lower()) if ch.isalnum())


VARIOUS = {"variousartists", "various", "va", "verschiedeneinterpreten", "artistesdivers", "variosartistas"}


def is_various(name):
    return _norm(name) in VARIOUS


def _art_key(artist, album, title="", albumartist=""):
    if album and (is_various(albumartist) or is_various(artist)):
        return hashlib.sha1(f"v2|various|{_norm(album)}".encode()).hexdigest()
    return hashlib.sha1(f"{_norm(artist)}|{_norm(album) or _norm(title)}".encode()).hexdigest()


def online_art(artist, album, title="", albumartist=""):
    """Look up cover art with Apple's public iTunes Search API. Results (and misses) are cached.
    Compilations ("Various Artists") are looked up by album name, because each track's own artist
    is not the album's artist - Apple lists DJ mixes and compilations under the DJ or label."""
    various = bool(album) and (is_various(albumartist) or is_various(artist))
    if not album and not title:
        return None
    if not artist and not various:
        return None
    key = _art_key(artist, album, title, albumartist)
    cdir = os.path.join(APP_DIR, "art_cache")
    os.makedirs(cdir, exist_ok=True)
    hit, miss = os.path.join(cdir, key + ".jpg"), os.path.join(cdir, key + ".none")
    if os.path.isfile(hit):
        with open(hit, "rb") as fh:
            return fh.read()
    if os.path.isfile(miss) and time.time() - os.path.getmtime(miss) < 30 * 86400:
        return None
    curl = which("curl")
    if not curl:
        return None

    def get(url, timeout=20):
        r = subprocess.run([curl, "-sfL", "-m", str(timeout), "-A", "AP30Sync/3", url], capture_output=True)
        return r.stdout if r.returncode == 0 else None

    def search(term, entity):
        url = "https://itunes.apple.com/search?" + urllib.parse.urlencode(
            {"term": term, "entity": entity, "limit": 25 if various else 10, "media": "music"})
        online_art.last = getattr(online_art, "last", 0)
        wait = 3.2 - (time.time() - online_art.last)      # Apple allows about 20 lookups a minute
        if wait > 0:
            time.sleep(wait)
        online_art.last = time.time()
        raw = get(url)
        if raw is None:
            raise OSError("offline")
        try:
            return json.loads(raw.decode("utf-8", "replace")).get("results", [])
        except ValueError:
            return []

    a_n, al_n, t_n = _norm(artist), _norm(album), _norm(title)

    def album_score(rc):
        if al_n and rc == al_n:
            return 3
        if al_n and rc and len(min(al_n, rc, key=len)) >= 8 and (al_n in rc or rc in al_n):
            return 2
        return 0

    def score(r):
        sc = 0
        ra, rc, rt = _norm(r.get("artistName")), _norm(r.get("collectionName")), _norm(r.get("trackName"))
        if ra == a_n:
            sc += 3
        elif a_n and ra and (a_n in ra or ra in a_n):
            sc += 2
        sc += album_score(rc)
        if t_n and rt == t_n:
            sc += 2
        return sc

    def va_score(r):
        """Compilation: the album name must match; prefer the plain album over a 'Mixed', 'DJ Mix' etc."""
        rc = _norm(r.get("collectionName"))
        sc = album_score(rc) * 10
        if sc:
            sc -= abs(len(rc) - len(al_n)) / 10.0
            if any(w in rc for w in ("djmix", "mixed", "dubmix", "karaoke", "tribute")) and \
               not any(w in al_n for w in ("djmix", "mixed", "dubmix", "karaoke", "tribute")):
                sc -= 5
        return sc

    def shorter(name):
        """The album name, then without a bracketed part or trailing words such as NORTH or Disc 1."""
        out = [name]
        base = re.sub(r"\s*[\(\[][^\)\]]*[\)\]]\s*$", "", name).strip()
        if base and base != name:
            out.append(base)
        words = base.split()
        while len(words) > 2 and len(out) < 4:
            words = words[:-1]
            if len(_norm(" ".join(words))) < 8:
                break
            out.append(" ".join(words))
        return out

    try:
        ok = False
        best = None
        if various:
            for term in shorter(album):
                results = search(term, "album")
                best = max(results, key=va_score, default=None)
                ok = best is not None and va_score(best) >= 15
                if ok:
                    break
        else:
            entity, term = ("album", f"{artist} {album}") if album else ("song", f"{artist} {title}")
            results = search(term, entity)
            best = max(results, key=score, default=None)
            ok = best is not None and score(best) >= 4
    except OSError:
        return None                                          # offline or refused: try again next time
    data = None
    if ok and best.get("artworkUrl100"):
        data = get(best["artworkUrl100"].replace("100x100bb", "600x600bb"))
    with open(hit if data else miss, "wb") as fh:
        fh.write(data or b"")
    return data


MUSIC_ART_SCRIPT = r'''
on run argv
    set outDir to item 1 of argv
    set idList to rest of argv
    set foundCount to 0
    repeat with pidItem in idList
        set pidText to contents of pidItem
        set artCount to 0
        set artData to missing value
        try
            tell application "Music"
                set theTrack to (first track of library playlist 1 whose persistent ID is pidText)
                set artCount to count of artworks of theTrack
                if artCount > 0 then set artData to raw data of artwork 1 of theTrack
            end tell
        end try
        if artData is not missing value then
            try
                set outFile to open for access (POSIX file (outDir & "/" & pidText & ".img")) with write permission
                set eof outFile to 0
                write artData to outFile
                close access outFile
                set foundCount to foundCount + 1
            on error
                try
                    close access outFile
                end try
            end try
        end if
    end repeat
    return foundCount
end run
'''


def music_art_dir():
    d = os.path.join(APP_DIR, "music_art")
    os.makedirs(d, exist_ok=True)
    return d


def music_art(pid):
    """Artwork the Music app supplied for a track (cached by its persistent ID), or None."""
    if not pid:
        return None
    p = os.path.join(music_art_dir(), pid + ".img")
    try:
        if os.path.getsize(p) > 100:
            with open(p, "rb") as fh:
                data = fh.read()
            if data[:2] == b"\xff\xd8" or data[:8] == b"\x89PNG\r\n\x1a\n":
                return data
            # some versions wrap the image: find the JPEG/PNG start
            for sig in (b"\xff\xd8\xff", b"\x89PNG\r\n\x1a\n"):
                i = data.find(sig)
                if 0 <= i < 1024:
                    return data[i:]
    except OSError:
        pass
    return None


def fetch_music_art(pids, log=lambda m: None, timeout=3600):
    """Ask the Music app for the artwork of these tracks (by persistent ID). Returns how many it gave.
    Needs macOS; the first time, macOS asks whether Terminal may control Music - click OK."""
    pids = [p for p in dict.fromkeys(pids) if p and not music_art(p)
            and not os.path.exists(os.path.join(music_art_dir(), p + ".none"))]
    if not pids or sys.platform != "darwin" or not which("osascript"):
        return 0
    d = music_art_dir()
    script = os.path.join(d, "get_artwork.applescript")
    with open(script, "w", encoding="utf-8") as fh:
        fh.write(MUSIC_ART_SCRIPT)
    log(f"Asking the Music app for the artwork of {len(pids)} tracks (macOS may ask you to allow this)...")
    r = None
    for i in range(0, len(pids), 400):                      # batches keep the command line short
        try:
            r = subprocess.run(["osascript", script, d] + pids[i:i + 400], capture_output=True, text=True,
                               timeout=timeout)
        except Exception as e:
            log(f"Couldn't get artwork from the Music app: {e}")
            return None
        if r.returncode != 0:
            break
    if r.returncode != 0:
        log("Couldn't get artwork from the Music app: " + (r.stderr.strip()[-300:] or "unknown error")
            + " - if macOS blocked it: System Settings › Privacy & Security › Automation › Terminal › Music."
            + " These tracks will be tried again next sync.")
        return None
    got = 0
    for p in pids:
        if music_art(p):
            got += 1
        else:
            open(os.path.join(d, p + ".none"), "w").close()     # don't ask again for tracks with no art
    log(f"The Music app supplied artwork for {got} of {len(pids)} tracks.")
    return got


def source_art(path, meta=None, allow_online=False):
    """Best cover for a track: its own art, its album folder's art, the Music app's artwork
    (e.g. iTunes Store artwork that isn't stored in the file), then (optionally) online."""
    data = embedded_art(path)
    if data:
        return data
    if meta and meta.get("pid"):
        data = music_art(meta["pid"])
        if data:
            return data
    data = folder_art(os.path.dirname(path))
    if data:
        return data
    if allow_online and meta:
        try:
            return online_art(meta.get("artist"), meta.get("album"), meta.get("title"), meta.get("albumartist", ""))
        except Exception:
            return None
    return None


def shrink_image(data, size):
    """Baseline sRGB JPEG no larger than size x size. Returns (bytes, w, h) or (None,0,0)."""
    im = tools()["imagemagick"]
    if not im or not data:
        return None, 0, 0
    cmd = [im, "-", "-auto-orient", "-colorspace", "sRGB", "-resize", f"{size}x{size}>",
           "-background", "white", "-alpha", "remove", "-alpha", "off", "-strip",
           "-interlace", "none", "-sampling-factor", "4:2:0", "-quality", "90", "jpg:-"]
    try:
        r = subprocess.run(cmd, input=data, capture_output=True, timeout=60)
    except Exception:
        return None, 0, 0
    if r.returncode != 0 or not r.stdout:
        return None, 0, 0
    w = h = 0
    try:
        idt = [im, "identify", "-format", "%w %h", "-"] if im.endswith("magick") else \
              [os.path.join(os.path.dirname(im), "identify"), "-format", "%w %h", "-"]
        q = subprocess.run(idt, input=r.stdout, capture_output=True, timeout=30)
        w, h = (int(x) for x in q.stdout.decode().split()[:2])
    except Exception:
        pass
    return r.stdout, w, h


def online_art_cached(artist, album, title="", albumartist=""):
    if not artist and not is_various(albumartist):
        return None
    p = os.path.join(APP_DIR, "art_cache", _art_key(artist, album, title, albumartist) + ".jpg")
    if os.path.isfile(p) and os.path.getsize(p) > 0:
        with open(p, "rb") as fh:
            return fh.read()
    return None


def thumbnail(path, size=96, meta=None):
    """Cached small JPEG for the browser, keyed by album folder."""
    key = hashlib.sha1((os.path.dirname(path) + "|" + str(size)).encode()).hexdigest()
    out = os.path.join(APP_DIR, "thumbs", key + ".jpg")
    if os.path.isfile(out):
        with open(out, "rb") as fh:
            return fh.read()
    if meta:
        tk = os.path.join(APP_DIR, "thumbs", hashlib.sha1((path + "|" + str(size)).encode()).hexdigest() + ".jpg")
        if os.path.isfile(tk):
            with open(tk, "rb") as fh:
                return fh.read()
    data = source_art(path, meta)
    if not data and meta:
        data = online_art_cached(meta.get("artist"), meta.get("album"), meta.get("title"), meta.get("albumartist", ""))
        if data:
            key = hashlib.sha1((path + "|" + str(size)).encode()).hexdigest()   # per-track key for these
            out = os.path.join(APP_DIR, "thumbs", key + ".jpg")
    if not data:
        return None
    small, _, _ = shrink_image(data, size)
    small = small or data
    try:
        with open(out, "wb") as fh:
            fh.write(small)
    except OSError:
        pass
    return small


def embed_art(path, jpeg, w=0, h=0):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".flac":
        from mutagen.flac import FLAC, Picture
        f = FLAC(path)
        p = Picture()
        p.type, p.mime, p.desc, p.data, p.width, p.height, p.depth = 3, "image/jpeg", "", jpeg, w, h, 24
        f.clear_pictures()
        f.add_picture(p)
        f.save()
    elif ext == ".mp3":
        from mutagen.id3 import ID3, APIC, ID3NoHeaderError
        try:
            f = ID3(path)
        except ID3NoHeaderError:
            f = ID3()
        f.delall("APIC")
        f.add(APIC(encoding=3, mime="image/jpeg", type=3, desc="", data=jpeg))
        f.save(path, v2_version=3)
    elif ext in (".m4a", ".aac"):
        from mutagen.mp4 import MP4, MP4Cover
        f = MP4(path)
        if f.tags is None:
            f.add_tags()
        f.tags["covr"] = [MP4Cover(jpeg, imageformat=MP4Cover.FORMAT_JPEG)]
        f.save()


def retag(path, album, albumartist, pos, total):
    import mutagen
    f = mutagen.File(path, easy=True)
    if f is None:
        return
    if f.tags is None:
        f.add_tags()
    ext = os.path.splitext(path)[1].lower()
    f["album"] = album
    f["albumartist"] = albumartist
    is_mp3 = ext == ".mp3"
    if ext in (".flac", ".ogg", ".opus"):
        f.save()
        from mutagen import File as _F
        g = _F(path)
        set_vorbis(g, {"album": album, "albumartist": albumartist, "pos": pos, "total": total})
        g.save()
        return
    else:
        f["tracknumber"] = f"{pos}/{total}"
        f["discnumber"] = "1/1"
    if is_mp3:
        f.save(v2_version=3)
    else:
        f.save()


def jpeg_info(data):
    """('baseline'|'progressive'|'png'|'other', width, height) for an image, read from its header."""
    import struct
    if not data:
        return "none", 0, 0
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        w, h = struct.unpack(">II", data[16:24])
        return "png", w, h
    if data[:2] != b"\xff\xd8":
        return "other", 0, 0
    i = 2
    while i < len(data) - 9:
        if data[i] != 0xFF:
            i += 1
            continue
        m = data[i + 1]
        if m in (0xD8, 0x01) or 0xD0 <= m <= 0xD7:
            i += 2
            continue
        seg = struct.unpack(">H", data[i + 2:i + 4])[0]
        if m in (0xC0, 0xC1, 0xC2):
            h, w = struct.unpack(">HH", data[i + 5:i + 9])
            return ("progressive" if m == 0xC2 else "baseline"), w, h
        i += 2 + seg
    return "other", 0, 0


def art_ok(data, size, pic_type=3):
    """True if the AP30 can show this cover: a front-cover baseline JPEG no bigger than size x size."""
    kind, w, h = jpeg_info(data)
    return kind == "baseline" and 0 < max(w, h) <= size + 2 and pic_type == 3 and len(data) <= 300_000


def card_art(path):
    """(image bytes, picture type) of the cover embedded in a file on the card."""
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext == ".mp3":
            from mutagen.id3 import ID3
            ap = ID3(path).getall("APIC")
            if ap:
                a = next((x for x in ap if x.type == 3), ap[0])
                return a.data, (3 if (a.type == 3 and len(ap) == 1) else 0)
            return None, 0
        if ext == ".flac":
            from mutagen.flac import FLAC
            pics = FLAC(path).pictures
            if pics:
                p = next((x for x in pics if x.type == 3), pics[0])
                return p.data, (3 if (p.type == 3 and len(pics) == 1) else 0)
            return None, 0
        return embedded_art(path), 3
    except Exception:
        return None, 0


def vorbis_lowercase(path):
    try:
        if os.path.splitext(path)[1].lower() in (".flac", ".ogg", ".opus"):
            from mutagen import File as _F
            return any(k != k.upper() for k, _ in (_F(path).tags or []))
    except Exception:
        return True
    return False


def card_file_needs_fix(path, size=300):
    """True if a file on the card has no cover art, or (MP3) uses ID3v2.4."""
    try:
        ext = os.path.splitext(path)[1].lower()
        if ext == ".mp3":
            from mutagen.id3 import ID3
            if ID3(path).version[1] != 3:
                return True
        if vorbis_lowercase(path):
            return True
        data, ptype = card_art(path)
        return not art_ok(data, size, ptype)
    except Exception:
        return True


def art_for_card(path, src, meta, cfg):
    """Decide the cover a card file needs, without writing anything.
    Returns (jpeg or None, width, height, how)."""
    size = int(cfg.get("art_size", 300))
    have, ptype = card_art(path)
    if have and art_ok(have, size, ptype):
        return None, 0, 0, "had art"
    data = have or source_art(src, meta, allow_online=cfg.get("online_art", True))
    if data:
        small, w, h = shrink_image(data, size)
        if small:
            return small, w, h, ("art converted" if have else "art added")
    return None, 0, 0, "no art found"


def set_vorbis(f, rt):
    """Playlist tags for FLAC/Ogg, with the field names in UPPER CASE - the AP30's firmware only
    recognises upper-case names (ALBUM, not album), although the standard says case doesn't matter."""
    for k in ("ALBUM", "ALBUMARTIST", "ALBUM ARTIST", "TRACKNUMBER", "TRACKTOTAL", "TOTALTRACKS",
              "DISCNUMBER", "DISCTOTAL", "TOTALDISCS"):
        if k in f:                                       # removes any spelling (case-insensitive)
            del f[k]
    f.tags.append(("ALBUM", rt["album"]))
    f.tags.append(("ALBUMARTIST", rt["albumartist"]))
    f.tags.append(("TRACKNUMBER", str(rt["pos"])))
    f.tags.append(("TRACKTOTAL", str(rt["total"])))
    f.tags.append(("DISCNUMBER", "1"))
    # tidy: make every other field name upper case too
    items = list(f.tags)
    if any(k != k.upper() for k, _ in items):
        f.tags.clear()
        for k, v in items:
            f.tags.append((k.upper(), v))


RETRY_DAYS = 7         # songs with no cover anywhere are looked at again after this many days
F_NOCACHE = 48        # macOS fcntl: read straight from the device, not from memory
F_FULLFSYNC = 51      # macOS fcntl: make the device itself store the data (not just its cache)


def _sha(path, uncached=False):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        if uncached:
            try:
                import fcntl
                fcntl.fcntl(fh.fileno(), F_NOCACHE, 1)
            except (ImportError, OSError):
                pass
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


class CardWriteError(IOError):
    """A file written to the card didn't read back the same - the card or card reader is losing data."""


def cover_now_available(j):
    """For a song that had no cover: is one available now without going online (a cover.jpg
    added to its folder, artwork added to the file, or one already fetched)? Then it is
    rewritten straight away; otherwise it waits for the weekly online look."""
    m = j.get("meta") or {}
    try:
        if source_art(j["src"], m, allow_online=False):
            return True
        return bool(online_art_cached(m.get("artist"), m.get("album"), m.get("title"), m.get("albumartist", "")))
    except Exception:
        return False


def write_card_file(local, dest, tries=2):
    """Put a finished file on the card safely:
    - write it whole, front to back, under a temporary name (files on the card are never edited
      in place - every change is made to a copy on this Mac first);
    - make the card itself store it (full flush), then read it back from the card, not from the
      Mac's memory, and compare it with the original;
    - only then give it its real name. A mismatch is written again; if it still doesn't match,
      the card or card reader is losing data and the sync stops with a warning."""
    want = _sha(local)
    part = dest + ".ap30tmp"
    for attempt in range(tries):
        with open(local, "rb") as src, open(part, "wb") as out:
            shutil.copyfileobj(src, out, 1 << 20)
            out.flush()
            try:
                import fcntl
                fcntl.fcntl(out.fileno(), F_FULLFSYNC)
            except (ImportError, OSError):
                os.fsync(out.fileno())
        if _sha(part, uncached=True) == want:
            os.replace(part, dest)
            return attempt
        try:
            os.remove(part)
        except OSError:
            pass
    raise CardWriteError(f"{os.path.basename(dest)} didn't read back correctly from the card "
                         f"after {tries} tries - the card or card reader is losing data")


def update_card_file(path, rt, jpeg=None, w=0, h=0):
    """Write playlist tags (rt) and/or a new cover to a file on the card in ONE save.
    MP3s are always saved as ID3v2.3."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".mp3":
        from mutagen.id3 import ID3, ID3NoHeaderError, TALB, TPE2, TRCK, TPOS, APIC
        try:
            t = ID3(path)
        except ID3NoHeaderError:
            t = ID3()
        if rt:
            t.setall("TALB", [TALB(encoding=3, text=rt["album"])])
            t.setall("TPE2", [TPE2(encoding=3, text=rt["albumartist"])])
            t.setall("TRCK", [TRCK(encoding=3, text=f"{rt['pos']}/{rt['total']}")])
            t.setall("TPOS", [TPOS(encoding=3, text="1/1")])
        if jpeg:
            t.delall("APIC")
            t.add(APIC(encoding=3, mime="image/jpeg", type=3, desc="", data=jpeg))
        if rt or jpeg or t.version[1] != 3:
            t.save(path, v2_version=3)
    elif ext in (".m4a", ".aac"):
        from mutagen.mp4 import MP4, MP4Cover
        f = MP4(path)
        if f.tags is None:
            f.add_tags()
        if rt:
            f.tags["\xa9alb"] = [rt["album"]]
            f.tags["aART"] = [rt["albumartist"]]
            f.tags["trkn"] = [(rt["pos"], rt["total"])]
            f.tags["disk"] = [(1, 1)]
        if jpeg:
            f.tags["covr"] = [MP4Cover(jpeg, imageformat=MP4Cover.FORMAT_JPEG)]
        if rt or jpeg:
            f.save()
    elif ext == ".flac":
        from mutagen.flac import FLAC, Picture
        f = FLAC(path)
        if f.tags is None:
            f.add_tags()
        upper_needed = any(k != k.upper() for k, _ in f.tags)
        if rt:
            set_vorbis(f, rt)
        elif upper_needed:
            items = list(f.tags)
            f.tags.clear()
            for k, v in items:
                f.tags.append((k.upper(), v))
        if jpeg:
            p = Picture()
            p.type, p.mime, p.desc, p.data, p.width, p.height, p.depth = 3, "image/jpeg", "", jpeg, w, h, 24
            f.clear_pictures()
            f.add_picture(p)
        if rt or jpeg or upper_needed:
            f.save()
    else:
        if rt:
            retag(path, rt["album"], rt["albumartist"], rt["pos"], rt["total"])
        if jpeg:
            embed_art(path, jpeg, w, h)


def ensure_art(path, src, meta, cfg, t):
    """Make sure a file on the card has a cover the AP30 can show (front-cover baseline JPEG,
    no bigger than the art size), converting whatever art it has, or finding some. MP3s end up ID3v2.3."""
    size = int(cfg.get("art_size", 300))
    is_mp3 = os.path.splitext(path)[1].lower() == ".mp3"
    have, ptype = card_art(path)
    if have and art_ok(have, size, ptype):
        if is_mp3:
            from mutagen.id3 import ID3
            t_ = ID3(path)
            if t_.version[1] != 3:
                t_.save(path, v2_version=3)
        return "had art"
    data = have or source_art(src, meta, allow_online=cfg.get("online_art", True))
    if data:
        small, w, h = shrink_image(data, size)
        if small:
            embed_art(path, small, w, h)
            return "art converted" if have else "art added"
    if is_mp3:
        from mutagen.id3 import ID3, ID3NoHeaderError
        try:
            ID3(path).save(path, v2_version=3)
        except ID3NoHeaderError:
            pass
    return "no art found"


# ---------------------------------------------------------------- FLAC library index

class Library:
    def __init__(self):
        self.path = os.path.join(APP_DIR, "index.json")
        self.tracks = load_json(self.path, {})       # path -> meta
        self.lock = threading.Lock()
        self.status = {"scanning": False, "done": 0, "total": 0, "message": "", "folders": {}, "version": 0}

    def scan(self, folders):
        if self.status["scanning"]:
            return
        threading.Thread(target=self._scan, args=(folders,), daemon=True).start()

    def _scan(self, folders):
        st = self.status
        st.update(scanning=True, done=0, total=0, message="Looking for music files...", folders={})
        try:
            files = []
            for folder in folders:
                folder = expand(folder)
                fsst = folder_status(folder)
                st["folders"][folder] = fsst
                if fsst != "ok":
                    continue
                for root, dirs, names in os.walk(folder):
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                    for n in names:
                        if n.startswith("._") or os.path.splitext(n)[1].lower() not in AUDIO:
                            continue
                        files.append(os.path.join(root, n))
                    st["message"] = f"Looking for music files... {len(files)} found"
            st["total"] = len(files)
            st["message"] = "Reading tags..."
            new = {}
            for i, p in enumerate(files, 1):
                try:
                    s_ = os.stat(p)
                except OSError:
                    continue
                old = self.tracks.get(p)
                if old and old.get("mtime") == s_.st_mtime and old.get("size") == s_.st_size:
                    new[p] = old
                else:
                    m = read_tags(p)
                    m.update(path=p, size=s_.st_size, mtime=s_.st_mtime)
                    new[p] = m
                st["done"] = i
                if i % 300 == 0:
                    with self.lock:
                        self.tracks = {**self.tracks, **new}
                    st["version"] = st.get("version", 0) + 1
                if i % 1000 == 0:
                    try:
                        save_json(self.path, {**self.tracks, **new})
                    except OSError:
                        pass
            with self.lock:
                if files or not any(v != "ok" for v in st["folders"].values()):
                    self.tracks = new
                save_json(self.path, self.tracks)
            bad = [f"{f} ({v})" for f, v in st["folders"].items() if v != "ok"]
            st["message"] = f"{len(new)} tracks" + (f" - can't read: {', '.join(bad)}" if bad else "")
        except Exception as e:
            st["message"] = f"Scan failed: {e}"
        finally:
            st["scanning"] = False
            st["version"] = st.get("version", 0) + 1

    def get(self, path):
        return self.tracks.get(path)

    def listing(self):
        with self.lock:
            return list(self.tracks.values())


# ---------------------------------------------------------------- iTunes / Music library

class ITunes:
    """Music app playlists from an exported Library.xml. Big files are read in the background."""

    def __init__(self):
        self.xml = None
        self.mtime = None
        self.playlists = []
        self.error = ""
        self.loading = False
        self.lock = threading.Lock()
        self.music_folder = None

    def ensure(self, xml, force=False):
        """Start loading in the background if the file is new or changed. Never blocks."""
        xml = expand(xml)
        if not force and getattr(self, "blocked_until", 0) > time.time() and xml == getattr(self, "blocked_xml", None):
            return
        try:
            mt = fs_call(os.path.getmtime, xml, timeout=3)
        except Blocked:
            self.blocked_until, self.blocked_xml = time.time() + 30, xml
            if not self.loading:
                self.error = (f"macOS isn't letting the app read {xml}. "
                              "Make sure the app is started from its app icon (it runs in Terminal).")
            return
        except OSError:
            if not self.loading:
                self.xml, self.mtime, self.playlists = xml, None, []
                self.error = f"Library.xml not found at {xml}. In the Music app: File > Library > Export Library..."
            return
        if self.loading or (not force and xml == self.xml and mt == self.mtime):
            return
        self.loading = True
        threading.Thread(target=self._load_safe, args=(xml, mt), daemon=True).start()

    def load(self, xml):
        """Make sure the playlists are loaded (waits if a background load is running)."""
        self.ensure(xml)
        while self.loading:
            time.sleep(0.1)

    def _load_safe(self, xml, mt):
        with self.lock:
            try:
                self._load(xml, mt)
            except Exception as e:
                self.error = f"Could not read {xml}: {e}"
                self.xml, self.mtime = xml, mt
            finally:
                self.loading = False

    def _load(self, xml, mt):
        with open(xml, "rb") as fh:
            lib = plistlib.load(fh)
        tracks = lib.get("Tracks", {})
        mf = lib.get("Music Folder")
        self.music_folder = urllib.parse.unquote(urllib.parse.urlparse(mf).path).rstrip("/") if mf else None
        out = []
        for pl in lib.get("Playlists", []):
            if pl.get("Master") or pl.get("Folder") or "Distinguished Kind" in pl or pl.get("Visible") is False:
                continue
            items = []
            for it in pl.get("Playlist Items", []):
                t = tracks.get(str(it.get("Track ID")), {})
                path, why = self.track_path(t)
                items.append({"path": path, "skip": why,
                              "title": t.get("Name", ""), "artist": t.get("Artist") or t.get("Album Artist") or "",
                              "album": t.get("Album", ""), "albumartist": t.get("Album Artist", "") or ("Various Artists" if t.get("Compilation") else ""),
                              "year": str(t.get("Year", "") or ""),
                              "duration": (t.get("Total Time") or 0) / 1000.0,
                              "pid": t.get("Persistent ID", ""), "art_count": t.get("Artwork Count", 0) or 0,
                              "size": t.get("Size") or 0})
            if not any(i["path"] for i in items):
                continue
            out.append({"name": pl.get("Name", "Untitled"), "smart": "Smart Info" in pl, "tracks": items})
        self.xml, self.mtime, self.playlists, self.error = xml, mt, out, ""

    @staticmethod
    def track_path(t):
        if t.get("Has Video") or t.get("Movie") or t.get("TV Show") or t.get("Music Video"):
            return None, "video"
        loc = t.get("Location")
        if not loc:
            return None, "not downloaded"
        path = urllib.parse.unquote(urllib.parse.urlparse(loc).path)
        ext = os.path.splitext(path)[1].lower()
        if ext == ".m4p" or t.get("Protected"):
            return None, "DRM protected"
        if ext not in AUDIO:
            return None, "not a music file"
        if not os.path.isfile(path):
            return None, "missing from disk"
        return path, None


# ---------------------------------------------------------------- planning

def estimate(size, duration, art_bytes, mode):
    if mode == "mp3":
        return int(duration * 40000) + 20000            # 320 kbit/s
    return max(0, int(size) - int(art_bytes or 0)) + (20000 if art_bytes else 0)


def build_jobs(store, library, itunes):
    """Every file that should exist on the card, grouped by playlist."""
    cfg = store.config
    groups = []
    plan = [(cfg["flac_root"], p["name"], p.get("mode", "copy"),
             [library.get(t) or {"path": t, "missing": True} for t in p["tracks"]], "flac")
            for p in store.playlists]
    excluded = {x.lower() for x in cfg.get("itunes_excluded", [])}
    for p in itunes.playlists:
        if p["name"].lower() in excluded:
            continue
        plan.append((cfg["itunes_root"], p["name"], "copy",
                     [t for t in p["tracks"] if t["path"]], "itunes"))

    seen = {}
    for root, name, mode, tracks, kind in plan:
        root = fat_name(root)
        folder = fat_name(name)
        k = (root.lower(), folder.lower())
        seen[k] = seen.get(k, 0) + 1
        if seen[k] > 1:
            folder = f"{folder} ({seen[k]})"
        ok = [t for t in tracks if not t.get("missing") and t.get("path") and os.path.isfile(t["path"])]
        missing = len(tracks) - len(ok)
        width = max(3, len(str(len(ok))))
        jobs = []
        for i, t in enumerate(ok, 1):
            src = t["path"]
            ext = ".mp3" if mode == "mp3" else os.path.splitext(src)[1].lower()
            artist = t.get("artist") or "Unknown Artist"
            title = t.get("title") or os.path.splitext(os.path.basename(src))[0]
            fname = fat_name(f"{i:0{width}d} - {artist} - {title}", 140) + ext
            rel = "/".join([root, folder, fname])
            album = f"{name} [FLAC]" if (kind == "flac" and cfg.get("flac_album_label", True)) else name
            rt = {"album": album, "albumartist": root, "pos": i, "total": len(ok)} if cfg.get("retag", True) else None
            base = hashlib.sha1(json.dumps([VERSION, mode, cfg.get("art_size", 300)]).encode()).hexdigest()[:16]
            tagv = 2 if ext in (".flac", ".ogg", ".opus") else 1          # 2 = upper-case Vorbis names
            extra = [tagv] if tagv > 1 else []
            if kind == "itunes" and not t.get("art_count", 1):
                extra.append("musicart2")       # art comes from the Music app (store artwork)
            sig = hashlib.sha1(json.dumps([base, rt] + extra).encode()).hexdigest()[:16]
            jobs.append({"rel": rel, "src": src, "mode": mode, "retag": rt, "sig": sig, "base": base,
                         "meta": {"artist": t.get("artist", ""), "album": t.get("album", ""), "title": t.get("title", ""),
                                  "albumartist": t.get("albumartist", ""),
                                  "pid": t.get("pid", "") if kind == "itunes" else "",
                                  "file_art": bool(t.get("art_count", 1)) if kind == "itunes" else True},
                         "est": estimate(t.get("size", 0), t.get("duration", 0), t.get("art_bytes", 0), mode)})
        groups.append({"kind": kind, "name": name, "root": root, "folder": folder, "mode": mode,
                       "jobs": jobs, "missing": missing})
    return groups


def dir_size(path):
    total = 0
    for r, _, ns in os.walk(path):
        for n in ns:
            try:
                total += os.path.getsize(os.path.join(r, n))
            except OSError:
                pass
    return total


def scan_card(card):
    card = expand(card)
    stt = folder_status(card)
    if stt == "missing":
        return {"ok": False, "error": f"Card not found at {card}. Is it inserted?"}
    if stt == "blocked":
        return {"ok": False, "error": f"macOS isn't letting the app read {card}."}
    du = shutil.disk_usage(card)
    top = []
    for n in sorted(os.listdir(card)):
        p = os.path.join(card, n)
        if n.startswith(".") or n.startswith("._"):
            continue
        if os.path.isdir(p):
            top.append({"name": n, "bytes": dir_size(p), "dir": True})
        elif os.path.isfile(p):
            top.append({"name": n, "bytes": os.path.getsize(p), "dir": False})
    top.sort(key=lambda x: -x["bytes"])
    nfiles = sum(len([n for n in ns if not n.startswith("._")]) for _, _, ns in os.walk(card))
    music_by_top = {}
    for d, ds, ns in os.walk(card):
        ds[:] = [x for x in ds if not x.startswith(".")]
        n = sum(1 for x in ns if not x.startswith(".") and os.path.splitext(x)[1].lower() in AUDIO | {".m4p", ".dsf", ".dff", ".ape", ".wma"})
        if n:
            tname = os.path.relpath(d, card).split(os.sep)[0]
            music_by_top[tname] = music_by_top.get(tname, 0) + n
    junk = count_mac_junk(card)
    for t_ in top:
        t_["tracks"] = music_by_top.get(t_["name"], 0)
    return {"ok": True, "card": card, "files": nfiles, "music_by_top": music_by_top, "junk": junk, "total": du.total, "used": du.used, "free": du.free, "top": top}


def adoptable(dest, j, src_stat):
    """A file already at the right place that wasn't made by this app (e.g. by ap30_playlists.py)."""
    try:
        if os.path.getmtime(dest) + 2 < src_stat.st_mtime:
            return False                                 # older than the source - re-copy
        if os.path.splitext(dest)[1].lower() != os.path.splitext(j["rel"])[1].lower():
            return False
        rt = j["retag"]
        if not rt:
            return "retag" if card_file_needs_fix(dest) else True
        import mutagen
        f = mutagen.File(dest, easy=True)
        if f is None or f.tags is None:
            return False
        album = (f.tags.get("album") or [""])[0]
        tn = str((f.tags.get("tracknumber") or [""])[0]).split("/")[0].strip()
        if (album != rt["album"] or tn != str(rt["pos"])
                or (f.tags.get("albumartist") or [""])[0] != rt["albumartist"]
                or card_file_needs_fix(dest)):
            return "retag"                               # right file - fix its tags/art in place
        return True
    except Exception:
        return False


# ------------------------------------------------------------- safety lock
# The app must never write to or delete from your source music. Every path it
# writes or deletes is checked against these rules first.

def _real(p):
    return os.path.realpath(expand(p)).rstrip("/") or "/"


def _inside(child, parent):
    return child == parent or child.startswith(parent + "/")


def protected_folders(cfg, itunes=None):
    """Folders holding your original music (never written to)."""
    out = [_real(f) for f in cfg.get("flac_folders", []) if f]
    if itunes is not None and getattr(itunes, "music_folder", None):
        out.append(_real(itunes.music_folder))
    out.append(_real("~/Music"))
    return out


def card_problem(cfg, itunes=None):
    """None if the card location is safe to write to, otherwise the reason it isn't."""
    raw = cfg.get("card") or ""
    if not raw:
        return "Set the card location in Settings."
    card = _real(raw)
    if card == "/" or card == _real("~") or _inside(_real("~"), card):
        return f"The card location ({raw}) is your Mac's disk or home folder, not a card."
    if sys.platform == "darwin" and not os.environ.get("AP30SYNC_ANY_CARD"):
        if not card.startswith("/Volumes/") or card.count("/") < 2:
            return f"The card location ({raw}) isn't a removable card. It should look like /Volumes/MUSICBOY."
        if card == os.path.realpath("/Volumes/Macintosh HD") or os.path.realpath(card) == "/":
            return "The card location is your Mac's startup disk."
        if _inside(card, _real("~")):
            return f"The card location ({raw}) is inside your home folder, not a card."
    for p in protected_folders(cfg, None):
        if _inside(card, p):
            return f"The card location ({raw}) is inside your music folder {p}. Refusing to write there."
    # original music may live ON the card only outside the playlist folders
    for p in protected_folders(cfg, itunes):
        if _inside(p, card):
            rel = p[len(card):].lstrip("/").split("/")[0]
            if p == card or rel.lower() in (fat_name(cfg["flac_root"]).lower(), fat_name(cfg["itunes_root"]).lower()):
                return f"Your music folder {p} overlaps the card's playlist folders. Refusing to sync."
    return None


def safe_card_path(path, card, roots, protected):
    """Raise unless path is inside one of the card's playlist folders and outside every source folder."""
    rp, card = os.path.realpath(path), _real(card)
    if not any(_inside(rp, os.path.join(card, r)) for r in roots):
        raise RuntimeError(f"Safety lock: refused to touch {path} (outside the card's playlist folders)")
    for p in protected:
        if _inside(rp, p):
            raise RuntimeError(f"Safety lock: refused to touch {path} (inside your music folder {p})")
    return path


def remove_mac_junk(card, protected=()):
    n = 0
    prot = [_real(p) for p in protected]
    for d, ds, ns in os.walk(card):
        ds[:] = [x for x in ds if x not in (".Spotlight-V100", ".fseventsd", ".Trashes", MANIFEST_DIR)
                 and not any(_inside(_real(os.path.join(d, x)), p) for p in prot)]
        if any(_inside(_real(d), p) for p in prot):
            continue
        for f in ns:
            if f.startswith("._") or f == ".DS_Store":
                p = os.path.join(d, f)
                try:
                    if os.path.getsize(p) <= 65536:       # AppleDouble files are tiny; never touch real music
                        remove_exact(p)
                        n += 1
                except OSError:
                    pass
    return n


def count_mac_junk(card):
    n = 0
    for d, ds, ns in os.walk(card):
        ds[:] = [x for x in ds if x not in (".Spotlight-V100", ".fseventsd", ".Trashes", MANIFEST_DIR)]
        n += sum(1 for f in ns if f.startswith("._"))
    return n


def manifest_path(card):
    return os.path.join(card, MANIFEST_DIR, "manifest.json")


def make_plan(store, library, itunes, progress=None):
    progress = progress or (lambda *a: None)
    _dir_art.clear()                    # notice cover images added since the last check
    cfg = store.config
    progress("Reading the card", 0, 0)
    card = expand(cfg["card"])
    problem = card_problem(cfg, itunes)
    if problem:
        return {"ok": False, "error": problem, "groups": []}
    groups = build_jobs(store, library, itunes)
    info = scan_card(card)
    if not info["ok"]:
        return {"ok": False, "error": info["error"], "groups": summarise(groups, {}, card, False)}
    manifest = load_json(manifest_path(card), {})
    roots = {fat_name(cfg["flac_root"]), fat_name(cfg["itunes_root"])}

    desired = {}
    for g in groups:
        for j in g["jobs"]:
            j["rel"] = nfc(j["rel"])
            desired[j["rel"]] = j
    manifest = {nfc(k): v for k, v in manifest.items()}

    keep_bytes = write_bytes = 0
    writes, keeps = [], []
    adopted = 0
    for n_, (rel, j) in enumerate(desired.items(), 1):
        if n_ % 50 == 0:
            progress("Comparing with what's on the card", n_, len(desired))
        dest = on_disk(os.path.join(card, rel))
        e = manifest.get(rel)
        try:
            s = os.stat(j["src"])
            up = (e and os.path.isfile(dest) and e.get("src") == j["src"] and e.get("mtime") == s.st_mtime
                  and e.get("size") == s.st_size
                  and (e.get("sig") == j["sig"]
                       # a song still without a cover is looked at again once a week, not every sync
                       or (e.get("sig") == "retry" and e.get("want_sig") == j["sig"]
                           and time.time() < e.get("retry_after", 0)
                           and not cover_now_available(j))))
            if not e and os.path.isfile(dest):
                a = adoptable(dest, j, s)
                if a is True:
                    # made earlier by the playlist script: same name, already tagged - keep it
                    manifest[rel] = {"src": j["src"], "mtime": s.st_mtime, "size": s.st_size,
                                     "sig": j["sig"], "base": j["base"], "adopted": True}
                    adopted += 1
                    up = True
                elif a == "retag":
                    j["reuse"] = rel                     # keep the file, just fix its tags
                    j["status"] = "update"
                    writes.append(rel)
                    continue
        except OSError:
            up = False
        if up:
            sz = os.path.getsize(dest)
            j["status"], j["actual"] = "ok", sz
            keep_bytes += sz
            keeps.append(rel)
        else:
            j["status"] = "new" if not os.path.exists(dest) else "update"
            write_bytes += j["est"]
            writes.append(rel)

    write_set = set(writes)
    removals, remove_bytes, managed_now = [], 0, 0
    seen_rel = set()
    for root in roots:
        rp = os.path.join(card, root)
        for r, _, ns in os.walk(rp):
            for n in ns:
                full = os.path.join(r, n)
                rel = nfc(os.path.relpath(full, card).replace(os.sep, "/"))
                try:
                    sz = os.path.getsize(full)
                except OSError:
                    sz = 0
                if rel in seen_rel:
                    continue                    # same file listed under two spellings
                seen_rel.add(rel)
                managed_now += sz
                if rel not in desired:
                    removals.append(os.path.relpath(full, card).replace(os.sep, "/"))
                    remove_bytes += sz
                elif rel in write_set:
                    remove_bytes += sz          # will be overwritten

    if adopted:
        try:
            os.makedirs(os.path.dirname(manifest_path(card)), exist_ok=True)
            save_json(manifest_path(card), manifest)
        except OSError:
            pass

    # Files already on the card with the same content (same source, same conversion) can be
    # renamed and re-tagged in place instead of copied again - e.g. after reordering a playlist.
    removal_set = set(removals)
    cands = {}
    for rel in list(removal_set) + writes:
        e = manifest.get(nfc(rel))
        if not e or not e.get("base") or not os.path.isfile(on_disk(os.path.join(card, rel))):
            continue
        cands.setdefault((e["src"], e["mtime"], e["size"], e["base"]), []).append(rel)
    reuse_count = sum(1 for r in writes if desired[r].get("reuse"))
    for rel in writes:
        j = desired[rel]
        if j.get("reuse"):
            continue
        try:
            s_ = os.stat(j["src"])
        except OSError:
            continue
        lst = cands.get((j["src"], s_.st_mtime, s_.st_size, j["base"]))
        if not lst:
            continue
        old = rel if rel in lst else lst[0]
        lst.remove(old)
        j["reuse"] = old
        j["status"] = "update"
        write_bytes -= j["est"]
        reuse_count += 1
        if old in removal_set:
            removal_set.discard(old)
            try:
                remove_bytes -= os.path.getsize(os.path.join(card, old))
            except OSError:
                pass
    removals = [r for r in removals if r in removal_set]
    for rel in writes:                                   # card space taken by reused files stays the same
        if desired[rel].get("reuse"):
            try:
                write_bytes += os.path.getsize(os.path.join(card, desired[rel]["reuse"]))
                remove_bytes += 0
            except OSError:
                pass

    other = max(0, info["used"] - managed_now)
    final_used = other + keep_bytes + write_bytes
    limit = int(float(cfg.get("limit_gb", 256)) * 1e9)
    flac_pl = sum((j.get("actual") or j["est"]) for g in groups if g["kind"] == "flac" for j in g["jobs"])
    itunes_pl = sum((j.get("actual") or j["est"]) for g in groups if g["kind"] == "itunes" for j in g["jobs"])

    # duplicate FLAC data: the same source copied into more than one FLAC playlist
    counts = {}
    for g in groups:
        if g["kind"] == "flac" and g["mode"] == "copy":
            for j in g["jobs"]:
                counts.setdefault(j["src"], []).append(j["est"])
    dup_bytes = sum(sum(v[1:]) for v in counts.values() if len(v) > 1)

    # ---- AP30 library track limit
    root_names = {fat_name(cfg["flac_root"]).lower(), fat_name(cfg["itunes_root"]).lower()}
    other_tracks = sum(n for top, n in info.get("music_by_top", {}).items() if top.lower() not in root_names)
    tracks_after = other_tracks + len(desired)
    track_limit = int(cfg.get("track_limit", 7000) or 7000)
    # duplicates: the same song copied into several playlists (each copy uses a library slot)
    srcs = {}
    for g in groups:
        for j in g["jobs"]:
            srcs.setdefault(j["src"], []).append(g["name"])
    unique_songs = len(srcs)
    overlap = []
    for g in groups:
        shared = sum(1 for j in g["jobs"] if len(srcs.get(j["src"], [])) > 1)
        if shared:
            overlap.append({"name": g["name"], "kind": g["kind"], "tracks": len(g["jobs"]), "shared": shared})
    overlap.sort(key=lambda x: (-x["shared"] / max(1, x["tracks"]), -x["shared"]))

    warnings = []
    for g in groups:
        if g["folder"] != fat_name(g["name"]):
            warnings.append(f"Two {'FLAC' if g['kind'] == 'flac' else 'iTunes'} playlists are called "
                            f"\"{g['name']}\", so the second one goes on the card as a separate folder "
                            f"\"{g['folder']}\" - a duplicate of every song both have. Rename or delete one "
                            f"of them before syncing.")
    if tracks_after > track_limit:
        warnings.append(f"After syncing the card would hold {tracks_after:,} tracks - over the AP30's library limit "
                        f"(set to {track_limit:,}). Tracks past the limit are silently left out of the AP30's "
                        f"library, and the scan may crash. Untick about {tracks_after - track_limit:,} tracks' worth "
                        f"of playlists, or raise the limit in Settings if you've tested a higher one.")
    if final_used > limit:
        warnings.append(f"After syncing, the card would hold {final_used/1e9:.1f} GB - over the AP30's "
                        f"~{limit/1e9:.0f} GB library limit. Music past the limit won't appear in the library.")
    if final_used > info["total"]:
        warnings.append("This won't fit on the card.")
    return {"ok": True, "card": info, "other_bytes": other, "flac_playlists_bytes": flac_pl,
            "itunes_playlists_bytes": itunes_pl, "final_used": final_used, "limit": limit,
            "write_count": len(writes) - reuse_count, "reuse_count": reuse_count,
            "write_bytes": write_bytes, "keep_count": len(keeps),
            "remove_count": len(removals), "remove_bytes": remove_bytes, "dup_bytes": dup_bytes,
            "copy_bytes": sum(desired[r]["est"] for r in writes if not desired[r].get("reuse")),
            "rewrite_bytes": sum(desired[r]["est"] for r in writes if desired[r].get("reuse")),
            "warnings": warnings, "groups": summarise(groups, manifest, card, True),
            "tracks_after": tracks_after, "track_limit": track_limit, "other_tracks": other_tracks,
            "unique_songs": unique_songs, "overlap": overlap[:15],
            "_writes": writes, "_removals": removals, "_desired": desired, "_itunes": itunes}


def summarise(groups, manifest, card, have_card):
    out = []
    for g in groups:
        st = {"new": 0, "update": 0, "ok": 0}
        for j in g["jobs"]:
            st[j.get("status", "new")] = st.get(j.get("status", "new"), 0) + 1
        out.append({"kind": g["kind"], "name": g["name"], "folder": g["root"] + "/" + g["folder"],
                    "mode": g["mode"], "tracks": len(g["jobs"]), "missing": g["missing"],
                    "bytes": sum((j.get("actual") or j["est"]) for j in g["jobs"]), "status": st})
    return out


# ---------------------------------------------------------------- syncing

class Syncer:
    def __init__(self):
        self.status = {"running": False, "phase": "", "done": 0, "total": 0, "bytes": 0,
                       "current": "", "log": [], "errors": 0, "finished": False}
        self.cancel = False

    def log(self, msg):
        self.status["log"].append(msg)
        self.status["log"] = self.status["log"][-400:]

    def start(self, store, plan):
        if self.status["running"]:
            return False
        self.cancel = False
        self.status = {"running": True, "phase": "Starting", "done": 0, "total": len(plan["_writes"]),
                       "bytes": 0, "current": "", "log": [], "errors": 0, "finished": False}
        threading.Thread(target=self._run, args=(dict(store.config), plan), daemon=True).start()
        return True

    def _run(self, cfg, plan):
        st = self.status
        self._card_failed = None
        written = 0
        card = expand(cfg["card"])
        mpath = manifest_path(card)
        try:
            problem = card_problem(cfg, plan.get("_itunes"))
            if problem:
                raise RuntimeError(problem)
            protected = protected_folders(cfg, plan.get("_itunes"))
            os.makedirs(os.path.dirname(mpath), exist_ok=True)
            manifest = {nfc(k): v for k, v in load_json(mpath, {}).items()}
            roots = [fat_name(cfg["flac_root"]), fat_name(cfg["itunes_root"])]
            guard = lambda p: safe_card_path(p, card, roots, protected)

            reuses = [r for r in plan["_writes"] if plan["_desired"][r].get("reuse")]
            copies = [r for r in plan["_writes"] if not plan["_desired"][r].get("reuse")]
            st["total"] = len(plan["_writes"])
            want = [plan["_desired"][r].get("meta", {}).get("pid") for r in plan["_writes"]
                     if not plan["_desired"][r].get("meta", {}).get("file_art", True)]
            music_ok = True
            if want:
                st["phase"] = "Getting cover art from the Music app"
                music_ok = fetch_music_art([p for p in want if p], self.log) is not None

            st["phase"] = "Rearranging files already on the card"
            moved = {}
            for rel in reuses:
                old = plan["_desired"][rel]["reuse"]
                if not any(old.startswith(r + "/") for r in roots):
                    continue
                if nfc(old) == nfc(rel):
                    moved[rel] = "SELF"                  # same place: nothing to move
                    continue
                aside = os.path.join(card, old + ".ap30move")
                try:
                    os.replace(guard(exact_name(on_disk(os.path.join(card, old)))), guard(aside))
                    moved[rel] = aside
                    manifest.pop(nfc(old), None)
                except OSError as e:
                    self.log(f"Could not move {old}: {e}")

            st["phase"] = "Removing old files"
            wanted = set(plan["_desired"])
            removed = 0
            for rel in plan["_removals"]:
                if nfc(rel) in wanted:
                    continue                     # safety: never remove a file a playlist needs
                full = on_disk(os.path.join(card, rel))
                if not any(rel.startswith(r + "/") for r in roots):
                    continue                     # never touch anything outside the playlist folders
                try:
                    remove_exact(guard(full))
                    manifest.pop(nfc(rel), None)
                    removed += 1
                except OSError as e:
                    st["errors"] += 1
                    self.log(f"Could not remove {rel}: {e}")
            if removed:
                self.log(f"Removed {removed} files no longer in any playlist")
            for r in roots:
                rp = os.path.join(card, r)
                for d, _, _ in sorted(os.walk(rp), key=lambda x: -len(x[0])):
                    if d != rp:
                        try:
                            os.rmdir(guard(exact_name(d)))   # only succeeds if empty
                        except OSError:
                            pass

            t = tools()
            st["phase"] = "Updating files already on the card (tags and cover art)"
            art_stats = {}
            no_art = []
            done = 0
            for rel in reuses:
                j = plan["_desired"][rel]
                aside = moved.get(rel)
                done += 1
                st["done"] = done
                st["current"] = rel
                if not aside:
                    copies.append(rel)                   # fall back to a full copy
                    continue
                try:
                    if aside == "SELF":
                        dest = guard(on_disk(os.path.join(card, rel)))
                    else:
                        dest = guard(os.path.join(card, rel))
                        os.makedirs(os.path.dirname(dest), exist_ok=True)
                        os.replace(aside, dest)
                    how = None
                    if j["mode"] != "mp3":
                        done -= 1                        # counted when it is written below
                        # Changed tags or cover (reordered, renamed, new settings, cover found):
                        # make the file afresh from the original rather than from the copy on the
                        # card, so an earlier damaged copy can never be carried forward.
                        copies.append(rel)
                        continue
                    if t["mutagen"]:
                        jpeg, w, h, how = (art_for_card(dest, j["src"], j.get("meta"), cfg) if t["imagemagick"]
                                           else (None, 0, 0, "no art tools"))
                        m_ = j.get("meta") or {}
                        if t["imagemagick"] and not m_.get("file_art", True) and music_art(m_.get("pid")):
                            small, w2, h2 = shrink_image(music_art(m_.get("pid")), int(cfg.get("art_size", 300)))
                            if small:            # Music app artwork replaces any earlier online guess
                                jpeg, w, h, how = small, w2, h2, "art from the Music app"
                        # edit a copy on this Mac, then write the whole file back and check it
                        fd, work = tempfile.mkstemp(prefix="ap30sync-", suffix=os.path.splitext(dest)[1])
                        os.close(fd)
                        try:
                            shutil.copyfile(dest, work)
                            update_card_file(work, j["retag"], jpeg, w, h)      # one save per file
                            write_card_file(work, dest)
                            written += 1
                        finally:
                            try:
                                os.remove(work)
                            except OSError:
                                pass
                        art_stats[how] = art_stats.get(how, 0) + 1
                        if how == "no art found":
                            no_art.append(rel)
                    st["bytes"] += os.path.getsize(dest)
                    s = os.stat(j["src"])
                    manifest[rel] = {"src": j["src"], "mtime": s.st_mtime, "size": s.st_size,
                                     "sig": j["sig"] if ((music_ok or (j.get("meta") or {}).get("file_art", True))
                                                         and not (how == "no art found" and cfg.get("online_art", True)))
                                            else "retry",
                                     "retry_after": time.time() + RETRY_DAYS * 86400, "want_sig": j["sig"],
                                     "base": j["base"]}
                except CardWriteError as e:
                    self._card_failed = str(e)
                    break
                except Exception as e:
                    self.log(f"Re-tag failed for {rel} ({e}) - copying it again instead")
                    copies.append(rel)
            for aside in moved.values():                 # anything left over
                if aside != "SELF" and os.path.exists(aside):
                    try:
                        os.remove(aside)
                    except OSError:
                        pass
            if reuses:
                cset = set(copies)
                n_upd = sum(1 for r_ in reuses if r_ not in cset)
                if n_upd:
                    self.log(f"Updated {n_upd} Compact MP3 files already on the card")
                if art_stats:
                    self.log("Cover art: " + ", ".join(f"{v} {k}" for k, v in art_stats.items()))
                save_json(mpath, manifest)

            st["phase"] = "Copying"
            tmpdir = tempfile.mkdtemp(prefix="ap30sync-")
            for i, rel in enumerate(copies, done + 1):
                if self.cancel:
                    self.log("Cancelled.")
                    break
                j = plan["_desired"][rel]
                st["current"] = rel
                dest = guard(os.path.join(card, rel))
                if self._card_failed:
                    break
                try:
                    need = j["est"] + 50 * 1024 * 1024
                    if shutil.disk_usage(card).free < need:
                        self.log("Card is full - stopping.")
                        st["errors"] += 1
                        break
                    self._art_missing = False
                    out = self._produce(j, cfg, tmpdir, t)
                    if self._art_missing:
                        no_art.append(rel)
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    if write_card_file(out, dest):
                        self.log(f"Note: {rel} needed a second try to write correctly to the card")
                    written += 1
                    os.remove(out)
                    s = os.stat(j["src"])
                    manifest[rel] = {"src": j["src"], "mtime": s.st_mtime, "size": s.st_size,
                                     "sig": j["sig"] if ((music_ok or (j.get("meta") or {}).get("file_art", True))
                                                         and not (self._art_missing and cfg.get("online_art", True)))
                                            else "retry",
                                     "retry_after": time.time() + RETRY_DAYS * 86400, "want_sig": j["sig"],
                                     "base": j["base"]}
                    st["bytes"] += os.path.getsize(dest)
                except CardWriteError as e:
                    st["errors"] += 1
                    self._card_failed = str(e)
                    try:
                        os.remove(dest + ".ap30tmp")
                    except OSError:
                        pass
                    break
                except Exception as e:
                    st["errors"] += 1
                    self.log(f"FAILED {rel}: {e}")
                    try:
                        os.remove(dest + ".ap30tmp")
                    except OSError:
                        pass
                st["done"] = i
                if i % 25 == 0:
                    save_json(mpath, manifest)
            shutil.rmtree(tmpdir, ignore_errors=True)
            save_json(mpath, manifest)
            if self._card_failed:
                st["phase"] = "Stopped - card problem"
                self.log("SYNC STOPPED: " + self._card_failed + ". Songs already checked are fine. "
                         "Try another card reader (or the Mac's built-in SD slot) and sync again; if it "
                         "happens again, the card itself may be failing - see the manual.")
            if no_art:
                self.log(f"{len(no_art)} songs have no cover art anywhere (not in the file, the Music app, "
                     "the album folder or online). For FLAC albums, put a cover.jpg in the album's folder; "
                     "for iTunes songs, add artwork in the Music app (Get Info › Artwork) and export "
                     "Library.xml again. The next sync tries these songs again:")
                for r_ in no_art:
                    self.log("   " + r_)

            # remove macOS "._" junk files from the whole card - the AP30 tries to play them
            st["phase"] = "Removing macOS junk files"
            junk = remove_mac_junk(card, protected)
            if junk:
                self.log(f"Removed {junk} hidden macOS junk files (._*) from the card")
            for r in roots:                              # folders emptied by renames or moves
                rp = os.path.join(card, r)
                for d, _, _ in sorted(os.walk(rp), key=lambda x: -len(x[0])):
                    if d != rp:
                        try:
                            os.rmdir(guard(exact_name(d)))   # only succeeds if empty
                        except OSError:
                            pass
            st["phase"] = ("Stopped - card problem" if self._card_failed else
                           "Finished" if not self.cancel else "Cancelled")
            self.log(f"Done: {written} files written and checked, {st['errors']} errors, "
                     f"{st['bytes']/1e9:.2f} GB written." + (" STOPPED EARLY - see above." if self._card_failed else ""))
        except Exception as e:
            st["phase"] = "Failed"
            st["errors"] += 1
            self.log(f"Sync failed: {e}")
        finally:
            st["running"] = False
            st["finished"] = True
            st["current"] = ""

    def _produce(self, j, cfg, tmpdir, t):
        src = j["src"]
        ext = os.path.splitext(j["rel"])[1]
        out = os.path.join(tmpdir, "work" + ext)
        if j["mode"] == "mp3":
            if not t["ffmpeg"]:
                raise RuntimeError("ffmpeg is needed for MP3 playlists (brew install ffmpeg)")
            cmd = [t["ffmpeg"], "-v", "error", "-y", "-i", src, "-map", "0:a:0", "-c:a", "libmp3lame",
                   "-b:a", "320k", "-map_metadata", "0", "-id3v2_version", "3", out]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0:
                raise RuntimeError("ffmpeg: " + (r.stderr.strip().splitlines() or ["failed"])[-1])
        else:
            shutil.copyfile(src, out)
        if t["mutagen"]:
            jpeg = w = h = None
            art = source_art(src, j.get("meta"), allow_online=cfg.get("online_art", True))
            if art and t["imagemagick"]:
                jpeg, w, h = shrink_image(art, int(cfg.get("art_size", 300)))
            if not jpeg and t["imagemagick"]:
                self._art_missing = True
            update_card_file(out, j["retag"], jpeg, w or 0, h or 0)     # tags + cover in one save
        return out
